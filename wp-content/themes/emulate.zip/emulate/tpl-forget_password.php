<?php
/**
 * Template Name: Forget Password
 *
 */
 
 
 if ( is_user_logged_in() )
{
	 
	$redirect = esc_url(get_bloginfo('url').'/reporting-dashboard/');
    wp_redirect($redirect);
	exit;
}

function tg_validate_url() {
    global $post;
    $page_url = esc_url(get_permalink( $post->ID ));
    $urlget = strpos($page_url, "?");
    if ($urlget === false) {
    $concate = "?";
    } else {
    $concate = "&";
    }
    return $page_url.$concate;
 }
 
 
$error = array();

if($_POST['action'] == "pwd_reset"){
    if ( !wp_verify_nonce( $_POST['pwd_nonce'], "pwd_reset_nonce")) {
    exit("No trick please");
    }
    if(empty($_POST['user_login'])) {
   	 $error[] ='<span class="error">*Please enter your username or e-mail address</span>';
    
    }
	else
	{
    
    $user_login = $wpdb->escape(trim($_POST['user_login']));
     
    if ( strpos($user_login, '@') ) {
		$user_data = get_user_by_email($user_login);
		if(empty($user_data) || $user_data->caps[administrator] == 1) {
		//the condition $user_data->caps[administrator] == 1 to prevent password change for admin users.
		//if you prefer to offer password change for admin users also, just delete that condition.
		$error[] ='<span class="error">*Invalid E-mail address!</span>';
		}
    }
    else {
    $user_data = get_userdatabylogin($user_login);
		if(empty($user_data) || $user_data->caps[administrator] == 1) {
		//the condition $user_data->caps[administrator] == 1 to prevent password change for admin users.
		//if you prefer to offer password change for admin users also, just delete that condition.
		$error[] ='<span class="error">*Invalid Username!</span>';
    
    }
	}
    }
     
	if(count($error)==0 && $user_data)
	{
    $user_login = $user_data->user_login;
    $user_email = $user_data->user_email;
     
    $key = $wpdb->get_var($wpdb->prepare("SELECT user_activation_key FROM $wpdb->users WHERE user_login = %s", $user_login));
    if(empty($key)) {
    //generate reset key
    $key = wp_generate_password(20, false);
    $wpdb->update($wpdb->users, array('user_activation_key' => $key), array('user_login' => $user_login));
    }
     
    //emailing password change request details to the user
    $message = __('Someone requested that the password be reset for the following account:') . "\r\n\r\n";
    $message .= get_option('siteurl') . "\r\n\r\n";
    $message .= sprintf(__('Username: %s'), $user_login) . "\r\n\r\n";
    $message .= __('If this was a mistake, just ignore this email and nothing will happen.') . "\r\n\r\n";
    $message .= __('To reset your password, visit the following address:') . "\r\n\r\n";
    $message .= tg_validate_url() . "action=reset_pwd&key=$key&login=" . rawurlencode($user_login) . "\r\n";
    if ( $message && !wp_mail($user_email, 'Password Reset Request', $message) ) {
    $error[]="<div class='error'>*Email failed to send for some unknown reason.</div>";
    
    }
    else $error[]='<div class="success">We have just sent you an email with Password reset instructions. <a href="'.get_option('siteurl').'/login/">click here to login</a></div>';
	}
}

if(isset($_POST['password_1']) && isset($_POST['password_2']) && $_GET['action'] == "reset_pwd" && isset($_GET['key']) &&  isset($_GET['login'])) {
	
	$pass1=trim($_REQUEST['password_1']);
	$pass2=trim($_REQUEST['password_2']);
	
	if(empty($pass1))
	{
	  $error[]='<span class="error">*Please enter new password.</span>';	
		
	}
	
	if(empty($pass2))
	{
	  $error[]='<span class="error">*Please re-enter new password.</span>';	
		
	}
	
	if($pass1!=$pass2)
	{
		 $error[]='<span class="error">*Password don\'t match. Enter correct password.</span>';	
		
	}
	
	
	if(count($error)==0)
	{
		$reset_key = $_GET['key'];
		$user_login = $_GET['login'];
		$user_data = $wpdb->get_row($wpdb->prepare("SELECT ID, user_login, user_email FROM $wpdb->users WHERE user_activation_key = %s AND user_login = %s", $reset_key, $user_login));
		$user_login = $user_data->user_login;
		$user_email = $user_data->user_email;
		if(!empty($reset_key) && !empty($user_data)) {
		$new_password = $pass1;
		wp_set_password( $new_password, $user_data->ID );
		//mailing the reset details to the user
		$message = __('Your new password for the account at:') . "\r\n\r\n";
		$message .= get_bloginfo('name') . "\r\n\r\n";
		$message .= sprintf(__('Username: %s'), $user_login) . "\r\n\r\n";
		$message .= sprintf(__('Password: %s'), $new_password) . "\r\n\r\n";
		$message .= __('You can now login with your new password at: ') . get_option('siteurl')."/login" . "\r\n\r\n";
		 
		if ( $message && !wp_mail($user_email, 'Password Reset Request', $message) ) {
			$error[]= "<div class='error'>Email failed to sent for some unknown reason</div>";
			 
		}
		else {
			$redirect_to = get_bloginfo('url')."/login?action=reset_success";
			wp_safe_redirect($redirect_to);
			 
		}
		}
		else exit('Not a Valid Key.');
	
	}
     
}


$layout = twoot_get_frontend_func('meta', 'layout')==false? 'right':twoot_get_frontend_func('meta', 'layout');
$widget = twoot_get_frontend_func('meta', 'sidebar')==false? 'page':twoot_get_frontend_func('meta', 'sidebar');
?>
<?php get_header(); ?>

<?php
	if( (twoot_get_frontend_func('meta', 'slideshow')==false) && !is_front_page() ) {
		echo twoot_generator('page_title', 'page'); 
	}
?>

<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<div class="site-content container pt pb clearfix">

<?php if($layout=='left') { echo twoot_generator('sidebar', $widget, $layout); } ?>

<article id="primary-wrapper" <?php twoot_layout_class();?>>
	<div class="inner">

	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
    <div id="post-<?php the_ID(); ?>">
        <div class="entry-content entry">
            <?php the_content(); ?>
          <div id="account-settings">   
            <?php if ( count($error) > 0 ) echo '<div id="result">'; echo implode("<br />", $error); echo '</div>'; ?>
             
             <form id="wp_pass_reset" action="" method="post" class="lost_reset_password">
             
             <?php	if( 'reset_pwd' == $_REQUEST['action'] && isset($_REQUEST['key']) && isset($_REQUEST['login']) ) : ?>
            
             <p><strong>Enter a new password below.</strong></p>
            
            <div class="form_field">
				<div class="frml"><label>New password <span class="required">*</span></label></div>
				<div class="frmr"><input type="password"  name="password_1" class="input-text"></div>
                <div class="clear"></div>
			</div>
            
            <div class="form_field">
				<div class="frml"><label>Re-enter new password <span class="required">*</span></label></div>
				<div class="frmr"><input type="password"  name="password_2" class="input-text"></div>
                <div class="clear"></div>
			</div>
              
             <input type="hidden" name="key" value="<?php echo isset( $_REQUEST['key'] ) ? $_REQUEST['key'] : ''; ?>" />
   			 <input type="hidden" name="login" value="<?php echo isset( $_REQUEST['login'] ) ? $_REQUEST['login'] : ''; ?>" />
            
            <?php else : ?>
            
             <p><strong>Lost your password? Please enter your username or email address. You will receive a link to create a new password via email.</strong></p>
             
             <div class="form_field">
				<div class="frml"><label for="username">Username or email <span class="required">*</span></label></div>
				<div class="frmr"><input type="text" id="user_login" name="user_login" class="input-text"></div>
                <div class="clear"></div>
			</div>
            <input type="hidden" name="action" value="pwd_reset" />
            <input type="hidden" name="pwd_nonce" value="<?php echo wp_create_nonce("pwd_reset_nonce"); ?>" />
 
             <?php endif; ?>

         <p class="form-row"><input type="submit" class="button" name="reset" value="Reset Password" /></p>
    
       

</form>
        
          
          </div>
        </div><!-- .entry-content -->
    </div><!-- .hentry .post -->
    <?php endwhile; ?>
<?php else: ?>
    <p class="no-data">
        <?php _e('Sorry, no page matched your criteria.', 'profile'); ?>
    </p><!-- .no-data -->
<?php endif; ?>

	</div>
</article>
<!--end #primary-->

<?php if($layout=='right') { echo twoot_generator('sidebar', $widget, $layout); } ?>

</div>
</div>
<!--end #content-->

<?php get_footer(); ?>