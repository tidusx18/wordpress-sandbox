<?php
/**
 * @package WordPress
 * @subpackage ThemeWoot
 * @author ThemeWoot Team 
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */
include_once( 'theme/themewoot.php' );

/**
*  Init Twoot class
*
* @since   1.0.0
*
*/
if ( class_exists( 'Twoot' ) ) {
	$GLOBALS['twoot'] = new Twoot();
}


/**
*  Add toolkit supports
*
* @since   1.0.0
*
*/
if( twoot_get_checked_func('toolkit_activated') ) { 

	// Post Types
	twoot_toolkit_support( 'post_type', array( 
		'portfolio', 
		'faq',
		'testimonial'
	) );


	// Shortcodes
	twoot_toolkit_support( 'shortcode', 'no', array(
		'accordion',
		'audio',
		'blog',
		'blog_carousel',
		'blog_grid',
		'blog_list',
		'blog_masonry',
		'button',
		'column',
		'faqs',
		'feature_services',
		'gmap',
		'hgroup',
		'icon',
		'icon_boxes',
		'image',
		'latest_blog',
		'left_tab',
		'message-box',
		'number',
		'portfolio_carousel',
		'portfolio_grid',
		'portfolio_list',
		'portfolio_masonry',
		'post_images',
		'post_masonry',
		'post_slider',
		'price_table',
		'progress_bar',
		'simple_buttons',
		'social_icons',
		'tab',
		'team_members',
		'testimonial',
		'testimonial_carousel',
		'title',
		'toggle',
		'twitter_carousel',
		'video'
	) );


	// Widgets
	twoot_toolkit_support( 'widget', array(
		'blog',
		'comments',
		'contact_details',
		'dribbble',
		'flickr',
		'instagram',
		'portfolio',
		'portfolio_tags',
		'social_icons',
		'twitter'
	) );

	if (!class_exists('WPBakeryVisualComposerAbstract')) {
		// Page Builder
		twoot_toolkit_support( 'js_composer');
	}
}


function report_custom_init() {
  $labels = array(
    'name'               => 'Reports',
    'singular_name'      => 'Report',
    'add_new'            => 'Add New',
    'add_new_item'       => 'Add New Report',
    'edit_item'          => 'Edit Report',
    'new_item'           => 'New Report',
    'all_items'          => 'All Reports',
    'view_item'          => 'View Report',
    'search_items'       => 'Search Reports',
    'not_found'          => 'No Reports found',
    'not_found_in_trash' => 'No Reports found in Trash',
    'parent_item_colon'  => '',
    'menu_name'          => 'Reporting Dashboard'
  );

  $args = array(
    'labels'             => $labels,
    'public'             => true,
    'publicly_queryable' => true,
    'show_ui'            => true,
    'show_in_menu'       => true,
    'query_var'          => true,
    'rewrite'            => false,
    'capability_type'    => 'post',
    'has_archive'        => true,
    'hierarchical'       => false,
    'menu_position'      => null,
    'supports'           => array( 'title')
  );

  register_post_type( 'report', $args );
  
  $labels = array(
		'name'              => _x( 'Sectors', 'taxonomy general name' ),
		'singular_name'     => _x( 'Sector', 'taxonomy singular name' ),
		'search_items'      => __( 'Search Sectors' ),
		'all_items'         => __( 'All Sectors' ),
		'parent_item'       => __( 'Parent Sector' ),
		'parent_item_colon' => __( 'Parent Sector:' ),
		'edit_item'         => __( 'Edit Sector' ),
		'update_item'       => __( 'Update Sector' ),
		'add_new_item'      => __( 'Add New Sector' ),
		'new_item_name'     => __( 'New Sector Name' ),
		'menu_name'         => __( 'Sectors' ),
	);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => false,
	);
 
 register_taxonomy( 'sector', array( 'report' ), $args );
 
 $labels = array(
		'name'              => _x( 'Authors', 'taxonomy general name' ),
		'singular_name'     => _x( 'Author', 'taxonomy singular name' ),
		'search_items'      => __( 'Search Authors' ),
		'all_items'         => __( 'All Authors' ),
		'parent_item'       => __( 'Parent Author' ),
		'parent_item_colon' => __( 'Parent Author:' ),
		'edit_item'         => __( 'Edit Author' ),
		'update_item'       => __( 'Update Author' ),
		'add_new_item'      => __( 'Add New Author' ),
		'new_item_name'     => __( 'New Author Name' ),
		'menu_name'         => __( 'Authors' ),
	);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => false,
	);
 
 register_taxonomy( 'author', array( 'report' ), $args );
 
 
 $labels = array(
		'name'                       => _x( 'Keywords', 'taxonomy general name' ),
		'singular_name'              => _x( 'Keyword', 'taxonomy singular name' ),
		'search_items'               => __( 'Search Keywords' ),
		'popular_items'              => __( 'Popular Keywords' ),
		'all_items'                  => __( 'All Keywords' ),
		'parent_item'                => null,
		'parent_item_colon'          => null,
		'edit_item'                  => __( 'Edit Keyword' ),
		'update_item'                => __( 'Update Keyword' ),
		'add_new_item'               => __( 'Add New Keyword' ),
		'new_item_name'              => __( 'New Keyword Name' ),
		'separate_items_with_commas' => __( 'Separate Keywords with commas' ),
		'add_or_remove_items'        => __( 'Add or remove Keywords' ),
		'choose_from_most_used'      => __( 'Choose from the most used Keywords' ),
		'not_found'                  => __( 'No Keywords found.' ),
		'menu_name'                  => __( 'Keywords' ),
	);

	$args = array(
		'hierarchical'          => false,
		'labels'                => $labels,
		'show_ui'               => true,
		'show_admin_column'     => true,
		'update_count_callback' => '_update_post_term_count',
		'query_var'             => true,
		'rewrite'               => false,
	);

	register_taxonomy( 'keywords', 'report', $args );
  
  
}
add_action( 'init', 'report_custom_init' );


function dashboard_report_callback()
{
	$args=array('post_type'=>'report','posts_per_page'=>20);
 
	if($_REQUEST['page'])
	{
		$paged=$_REQUEST['page'];	
	}
	else
	{
		$paged=1;
	}
	
	$args['paged']=$paged;
	
 
	
	
	$args['tax_query']['relation']='AND';
	if($_REQUEST['sector'] !=0)
	{
		 $args['tax_query'][]=array(
					'taxonomy' => 'sector',
					'field' => 'id',
					'terms' => $_REQUEST['sector']
				);
	}
	
	if($_REQUEST['author'] !=0)
	{
		 $args['tax_query'][]=array(
					'taxonomy' => 'author',
					'field' => 'id',
					'terms' => $_REQUEST['author']
				);
	}
	
	if($_REQUEST['s'] !='')
	{
		 $args['tax_query'][]=array(
					'taxonomy' => 'keywords',
					'field' => 'slug',
					'terms' => $_REQUEST['s']
				);
	}
		
	$the_query = new WP_Query( $args );
     

	  //print_r($the_query);
 
	if ( $the_query->have_posts() ) {
			$json="[{'data':[";
		while ( $the_query->have_posts() ) {
			$the_query->the_post();
			$title=get_the_title();
			
		   $id=get_the_ID();
			
			$sector_term_list = wp_get_post_terms($id, 'sector', array("fields" => "names"));
			
			if($sector_term_list && count($sector_term_list) > 0)
			{
				 
				//$sector=$sector_term_list[0];
				$sector=implode(', ',$sector_term_list);
				
			}
			
			$author_term_list = wp_get_post_terms($id, 'author', array("fields" => "names"));
			
			if($author_term_list && count($author_term_list) > 0)
			{
				$author=$author_term_list[0];
				
			}
			
			$date=get_field('date');
			
			if($date)
			{
 
				
				$date = date("m.d.Y", strtotime($date));
				
				 
			}
		
			 $json.="{'t':'$title' , 's':'$sector', 'a':'$author', 'd':'$date','id':'$id'},";
			
		}
		$json.="],'num_pages':$the_query->max_num_pages,'curr_page':$paged}]";
	}
	
	
	echo $json;
	
	exit;
	
}
	
	
	
	
add_action( 'wp_ajax_dashboard_report', 'dashboard_report_callback' );
add_action( 'wp_ajax_nopriv_dashboard_report', 'dashboard_report_callback' );	


if(isset($_REQUEST['download']) && $_REQUEST['download']=='pdf' && isset($_REQUEST['id']) &&  $_REQUEST['id']!='' && !is_admin())
{
	 
   if(!is_user_logged_in())
   {
	    $redirect=get_bloginfo('url').'/?download=pdf&id='.$_REQUEST['id'];
	  	$url=get_bloginfo('url').'/login/?redirect='.urlencode($redirect);
		wp_redirect($url);
		exit; 
   }
	   	 
  $post_id=trim($_REQUEST['id']);	
  $pdf_link=get_field('upload_report', $post_id); 
  
   
  
  $pdf_link =ABSPATH.strstr($pdf_link, '/wp-content');
  $upload_dir = wp_upload_dir(); 
  
    $basedir=$upload_dir['basedir'].'/users/';
  
  if (!file_exists($basedir)) {
	  mkdir($basedir, 0777);
  }
  
  global $current_user;
  get_currentuserinfo(); 
  
  if($current_user->user_firstname)
  {
	 $string=$current_user->user_firstname.' '.$current_user->user_lastname;
	  
  }
  elseif($current_user->display_name)
  {
	  $string=$current_user->display_name;
  }
  else
  {
	  $string=$current_user->user_login;
	  
  }
  

require_once('fpdf/fpdf.php');
require_once('fpdi/fpdi.php');
require_once("pdfwatermarker/pdfwatermarker.php");


function file_name_gen($string) {
    $string = strtolower($string);
    $string = preg_replace("/[^a-z0-9_\s-]/", "", $string);
    $string = preg_replace("/[\s-]+/", " ", $string);
    $string = preg_replace("/[\s_]/", "-", $string);
    return $string;
}

 
  
    $file_name=file_name_gen($string);
  $file_to_save=$basedir.$file_name.'.png';	
  

$im = new Imagick(); 
$draw = new ImagickDraw(); 
$draw->setFillColor(new ImagickPixel('black')); 
$draw->setFontSize(60); 
$metrix = $im->queryFontMetrics($draw, $string); 
$draw->annotation(0,60,$string); 
$im->newImage($metrix['textWidth'],$metrix['textHeight'], new ImagickPixel('white')); 
$im->drawImage($draw); 
$im->rotateImage(new ImagickPixel('white'),-45); 
$im->setImageOpacity(0.1);
 
$im->writeImage ($file_to_save);


$im = imagecreatefrompng($file_to_save);

imagealphablending($im, false);
imagesavealpha($im, true);

imagepng($im,$file_to_save);
 

$output='report-'.$file_name.'-'.$post_id.'.pdf';
$watermark = new PDFWatermark($file_to_save);
$watermarker = new PDFWatermarker($pdf_link,$output,$watermark);
$watermarker->setWatermarkPosition('bottom');
$watermarker->watermarkPdf();

/*$report_statistics=(array)get_post_meta($post_id,'_report_statistics',true);

 if($report_statistics && isset($report_statistics[$current_user->ID]))
{
 
		$cr=$report_statistics[$current_user->ID]+1;
		$report_statistics[$current_user->ID]=$cr;
 
}
else
{
	$report_statistics[$current_user->ID]=1;
	
}
update_post_meta($post_id,'_report_statistics',$report_statistics);*/


// start

 global $wpdb;
 $table_name = $wpdb->prefix . "report_stats";
 
 $user_id=$current_user->ID;
 
 $row = $wpdb->get_row("SELECT no_of_times,download_times FROM $table_name WHERE post_id=$post_id AND user_id=$user_id");

if ($row == null) {
   
   $no_of_times=1;
   $download_times=serialize(array(time()));
   
   $wpdb->insert( 
		$table_name, 
		array( 
			'user_id' => $user_id,
			'post_id'=>$post_id,
			'download_times' => $download_times	 ,
			'no_of_times' => $no_of_times
		), 
		array( 
			'%d',
			'%d',
			'%s',	 
			'%d'	 
		) 
		 
	);	 
	 
   
  
} else {
	
	$no_of_times=($row->no_of_times)?$row->no_of_times+1:1;
	$download_times=(array)unserialize($row->download_times);
	$download_times[]=time();
	
	$download_times=serialize($download_times);
	
	
	$wpdb->update( 
		$table_name, 
		array( 
			'download_times' => $download_times	 ,
			'no_of_times' => $no_of_times
		), 
		array( 'user_id' => $user_id,'post_id'=>$post_id), 
		array( 
			'%s',	 
			'%d'	 
		), 
		array( '%d','%d' ) 
	);
  
}


// end




exit;
	
}


function report_statistics_add_box() {

    

        add_meta_box(
            'report_statistics_id',
            __( 'Report Statistics', '' ),
            'report_statistics_add_box_callback',
            'report'
        );
 
}
add_action( 'add_meta_boxes', 'report_statistics_add_box' );

function report_statistics_add_box_callback()
{
	global $post,$wpdb;
	 
	
	$url=get_bloginfo('url');
	
	 
 	$table_name = $wpdb->prefix . "report_stats";
 
	$report_statistics = $wpdb->get_results("SELECT * FROM $table_name where post_id=".$post->ID);
	
	
	?>
    
    <table id="reporting_stats" border="0" cellspacing="0" width="60%">
      <tr>
       <th>S. NO.</th><th>User ID</th><th>Users</th> <th>Download Times</th>
      </tr>
      
      <?php 
	   
	   if($report_statistics && count($report_statistics)>0)
	{
		
		$i=1;
		foreach($report_statistics as $rv)
		{
			if($rv)
			{
			$user_info = get_userdata($rv->user_id);
			
			if($user_info->first_name)
			{
				$username= $user_info->first_name.' '.$user_info->last_name;
			}
			else
			{
				$username= $user_info->display_name;
			}
			
			?>
            
            <tr>
            <td><?php echo $i++; ?></td>
            <td><?php echo $user_info->ID; ?></td> <td><a target="_blank" href="<?php echo $url; ?>wp-admin/admin.php?post_type=report&page=user_download_reports&action=show_report&user_id=<?php echo $user_info->ID;  ?>"><?php echo $username; ?></a></td><td><?php echo $rv->no_of_times; ?></td>
            </tr>
            
            <?php
			}
		}
		
	}
	  
	  ?>
    
    </table>
    
    <style type="text/css">
     #reporting_stats td,#reporting_stats th
	 {
		border: 1px solid #CCCCCC;
		padding: 3px 2px;
		text-align: center;
	 }
	 
	 #reporting_stats 
	 {
		  border-collapse: collapse;
	 } 
	 
	 #report_statistics_id .inside
	 {
		max-height:450px;
		overflow:auto; 
		 
	 }
	 
	 #reporting_stats  a
	 {
		 text-decoration:none;
	 }
    </style>
    
	<?php 
}



function jal_install() {
   global $wpdb;

   $table_name = $wpdb->prefix . "report_stats";
      
   $sql = "CREATE TABLE $table_name (
  user_id mediumint(9) NOT NULL,
  post_id mediumint(9) NOT NULL,
  no_of_times mediumint(9) NOT NULL,
  download_times text NOT NULL,
  CONSTRAINT puid PRIMARY KEY (user_id,post_id)
    );";

   require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
   dbDelta( $sql );
 
   
}

if($_REQUEST['create_db']==1)
{
 
 //jal_install();	
 
/* global $wpdb;
 
 $stats=array('times'=>4,'time_stamp'=>444);
 
 $post_id=1;
 $user_id=1;
 
 $wpdb->replace( 
	$wpdb->prefix . "report_stats", 
	array( 
		'user_id' => $user_id,'post_id' => $post_id,
		'stats' => serialize($stats),	 	 
	), 
	array( 
		'%d','%d','%s',	 	 
	) 
);*/
 
	
}



if( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class User_Report_List_Table extends WP_List_Table {
	
	function get_columns(){
	  $columns = array(
	  'cb'        => '<input type="checkbox" />',
		'email'    => 'Email',
		'name' => 'Name',
	  );
	  return $columns;
	}
	
	
	function column_default( $item, $column_name ) {
	  switch( $column_name ) { 
	    case 'email':
		case 'name':
		
		  return $item[ $column_name ];
		default:
		  return print_r( $item, true ) ; //Show the whole array for troubleshooting purposes
	  }
	}
	
	function column_cb($item) {
        return sprintf(
            '<input type="checkbox" name="uid[]" value="%s" />', $item['ID']
        );    
    }

	
	
	function prepare_items() {
	  $columns = $this->get_columns();
	  $hidden = array();
	  $sortable = array();
	  $this->_column_headers = array($columns, $hidden, $sortable);
	  
	  global $wpdb;
	  $table_name = $wpdb->prefix . "report_stats";
      $row = $wpdb->get_var("SELECT COUNT(DISTINCT user_id) as count FROM $table_name");
	  
	  $total_items =$row->count;
	  
	 $per_page=20;
	  
	  
	  $total_pages = ceil( $total_items / $per_page );
	  
	  
	  $this->set_pagination_args( array(
			'total_items' => $total_items,
			'total_pages' => $total_pages,
			'per_page' => $per_page
		) );
		
		$current_page = $this->get_pagenum();
		
		$offset=($current_page-1)*$per_page;
		
	   $user_ids = $wpdb->get_results("SELECT DISTINCT user_id FROM $table_name LIMIT $offset,$per_page");
	   
	   if($user_ids)
	   {
		$i=0;
		$items=array();
	   foreach($user_ids as $uid)
	   {
		   
		   if($uid->user_id)
		   {
		   $user_info=get_userdata( $uid->user_id );
			
			if($user_info->first_name)
			{
				$username= $user_info->first_name.' '.$user_info->last_name;
			}
			else
			{
				$username= $user_info->display_name;
			}
			$items[$i]['ID']=$uid->user_id;
			
			$items[$i]['email']='<a href="?post_type=report&page=user_download_reports&action=show_report&user_id='.$uid->user_id.'">'.$user_info-> user_email.'</a>' ;
			
			$items[$i]['name']=$username;
			
			$i++;
	   }
	   }
	
	   }
	
	  
	 $this->items = $items;
	}

}

function user_download_reports_add_menu_items(){
    //add_menu_page( 'User Download Reports', 'User Download Reports', 'activate_plugins', 'user_download_reports', 'user_download_reports_render_list_page' );
	
	add_submenu_page( 'edit.php?post_type=report', 'User Download Reports', 'User Download Reports', 'manage_options', 'user_download_reports', 'user_download_reports_render_list_page' ); 
}
add_action( 'admin_menu', 'user_download_reports_add_menu_items' );

function user_download_reports_render_list_page(){
	
  
  echo '<div class="wrap"><div class="icon32" id="icon-users"><br></div><h2>User Download Reports</h2>'; 
  
  if($_REQUEST['action']=='show_report' && $_REQUEST['user_id'] !='')
  {
	 $user_id=$_REQUEST['user_id'];
	  
   global $post,$wpdb;
   $table_name = $wpdb->prefix . "report_stats";
   $report_statistics = $wpdb->get_results("SELECT * FROM $table_name where user_id=$user_id");
	
	
	$user_info=get_userdata( $user_id );
			
	if($user_info->first_name)
	{
		$username= $user_info->first_name.' '.$user_info->last_name;
	}
	else
	{
	    $username= $user_info->display_name;
	}
			
	  ?>
	  <br />
      
      <p>
      <strong>User ID :</strong> <?php echo $user_id; ?> <br />
      <strong>Name :</strong> <?php echo $username; ?> <br />
		<strong>Email :</strong> <?php echo $user_info->user_email; ?></p>

 <br />



	 <table id="reporting_stats" border="0" cellspacing="0" width="60%">
      <tr>
       <th>S. NO.</th><th>Report ID</th><th>Report Name</th><th>No. of times download</th><th>Date/Time</th>
      </tr>
      
      <?php 
	   
	   if($report_statistics && count($report_statistics)>0)
	{
		
		$i=1;
		$url=get_bloginfo('url');
		foreach($report_statistics as $rv)
		{
			if($rv)
			{
			 
			 $post_id=$rv->post_id;
			 
			 $post=get_post($post_id);
			
			?>
            
            <tr>
            <td><?php echo $i++; ?></td><td><?php echo $post_id; ?></td>
            <td><a href="<?php echo $url; ?>/wp-admin/post.php?post=<?php echo $post_id; ?>&action=edit"><?php echo $post->post_title; ?></a></td> <td><?php echo $rv->no_of_times; ?></td> 
            
            
           
            <td> <?php 
			
			$download_times=unserialize($rv->download_times);
			  
			  if($download_times && is_array($download_times))
			  {
				  foreach($download_times as $timestamp)
				  {
				     
					echo '<strong>'.date("Y-m-d H:i:s",$timestamp).'</strong>'.'</br>';
				    
				  }
			  }
			
			?></td>
            </tr>
            
            <?php
			}
		}
		
	}
	  
	  ?>
    
    </table>
    
    <style type="text/css">
     #reporting_stats td,#reporting_stats th
	 {
		border: 1px solid #CCCCCC;
		padding: 3px 2px;
		text-align: center;
	 }
	 
	 #reporting_stats 
	 {
		  border-collapse: collapse;
	 } 
	 
	  
	 
	 	 #reporting_stats  a
	 {
		 text-decoration:none;
	 }
    </style>
    
    <?php
	   
	  
  }
  else
  {
  $myListTable = new User_Report_List_Table();
  $myListTable->prepare_items(); 
  $myListTable->display(); 
  }
  echo '</div>'; 
}


