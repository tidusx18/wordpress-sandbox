<?php
/**
 * WPBakery Visual Composer Shortcodes settings
 *
 * @package VPBakeryVisualComposer
 *
 */

// Params
$animation_opts = array(
	__('No', 'Twoot') => '', 
	__('Fade In', 'Twoot') => 'fadeIn', 
	__('Fade In Left', 'Twoot') => 'fadeInLeft', 
	__('Fade In Right', 'Twoot') => 'fadeInRight', 
	__('Fade In Up', 'Twoot') => 'fadeInUp', 
	__('Fade In Down', 'Twoot') => 'fadeInDown'
);

$repeat_opts = array(
	__('No Repeat', 'Twoot') => 'no-repeat',
	__('Repeat only Horizontally', 'Twoot') => 'repeat-x',
	__('Repeat only Vertically', 'Twoot') => 'repeat-y',
	__('Repeat both Vertically and Horizontally', 'Twoot') => 'repeat'
);

$horizontal_opts = array(
	__('Left', 'Twoot') => 'left',
	__('Right', 'Twoot') => 'right',
	__('Center', 'Twoot') => 'center'
);

$vertical_opts = array(
	__('Top', 'Twoot') => 'top',
	__('Bottom', 'Twoot') => 'bottom',
	__('Center', 'Twoot') => 'center'
);

$attachment_opts = array(
	__('Fixed', 'Twoot') => 'fixed',
	__('Scroll', 'Twoot') => 'scroll'
);

$tax_opts = array(
	__('Cat', 'Twoot') => 'cat',
	__('Tag', 'Twoot') => 'tag'
);

$column_opts = array(
	__('2 Column', 'Twoot') => '2',
	__('3 Column', 'Twoot') => '3',
	__('4 Column', 'Twoot') => '4'
);

$order_opts = array(
	__('ASC', 'Twoot') => 'ASC',
	__('DESC', 'Twoot') => 'DESC'
);

$orderby_opts = array(
	__('ID', 'Twoot') => 'ID',
	__('Title', 'Twoot') => 'title',
	__('Name', 'Twoot') => 'name',
	__('Date', 'Twoot') => 'date',
	__('Rand', 'Twoot') => 'rand',
	__('Menu Order', 'Twoot') => 'menu_order'
);

$slider_num_opts = array(
	__('1 Item', 'Twoot') => '1',
	__('2 Item', 'Twoot') => '2',
	__('3 Item', 'Twoot') => '3',
	__('4 Item', 'Twoot') => '4'
);



// Row
vc_map( array(
	'name' => __('Row', 'Twoot'),
	'base' => 'vc_row',
	'is_container' => true,
	'icon' => '',
	'show_settings_on_create' => false,
	'category' => __('Content', 'Twoot'),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __('Padding Top', 'Twoot'),
			'param_name' => 'pt',
			'description' => __('Set the section from top, the unit is pixel.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Padding Bottom', 'Twoot'),
			'param_name' => 'pb',
			'description' => __('Set the section from bottom, the unit is pixel.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Text Color', 'Twoot'),
			'param_name' => 'text_color',
			'description' => __('Set the section text color, ex: "#FFFFFF".', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Background Color', 'Twoot'),
			'param_name' => 'bg_color',
			'description' => __('Set the section background color, ex: "#FFFFFF".', 'Twoot')
		),
		array(
			'type' => 'attach_image',
			'heading' => __('Image', 'Twoot'),
			'param_name' => 'bg_image',
			'value' => '',
			'description' => __('Select image from media library.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Image Repeat', 'Twoot'),
			'param_name' => 'bg_repeat',
			'value' => $repeat_opts,
			'description' => __('Select title location.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Image Horizontal', 'Twoot'),
			'param_name' => 'bg_horizontal',
			'value' => $horizontal_opts,
			'description' => __('Select title location.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Image Vertical', 'Twoot'),
			'param_name' => 'bg_vertical',
			'value' => $vertical_opts,
			'description' => __('Select title location.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Image Position', 'Twoot'),
			'param_name' => 'bg_attachment',
			'value' => $attachment_opts,
			'description' => __('Select title location.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Extra class name', 'Twoot'),
			'param_name' => 'el_class',
			'description' => __('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'Twoot')
		)
	),
	'js_view' => 'VcRowView'
) );


// Row Inner
vc_map( array(
	'name' => __('Row', 'Twoot'), //Inner Row
	'base' => 'vc_row_inner',
	'content_element' => false,
	'is_container' => true,
	'icon' => 'icon-wpb-row',
	'show_settings_on_create' => false,
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __('Padding Top', 'Twoot'),
			'param_name' => 'pt',
			'description' => __('Set the section from top, the unit is pixel.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Padding Bottom', 'Twoot'),
			'param_name' => 'pb',
			'description' => __('Set the section from bottom, the unit is pixel.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Extra class name', 'Twoot'),
			'param_name' => 'el_class',
			'description' => __('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'Twoot')
		)
	),
	'js_view' => 'VcRowView'
) );


// Text Block
vc_map( array(
	'name' => __('Text Block', 'Twoot'),
	'base' => 'vc_column_text',
	'icon' => '',
	'wrapper_class' => 'clearfix',
	'category' => __('Content', 'Twoot'),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __('Padding Top', 'Twoot'),
			'param_name' => 'pt',
			'description' => __('Set the section from top, the unit is pixel.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Padding Bottom', 'Twoot'),
			'param_name' => 'pb',
			'description' => __('Set the section from bottom, the unit is pixel.', 'Twoot')
		),
		array(
			'type' => 'textarea_html',
			'holder' => 'div',
			'heading' => __('Text', 'Twoot'),
			'param_name' => 'content',
			'value' => __('<p>I am text block. Click edit button to change this text.</p>', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('CSS Animation', 'Twoot'),
			'param_name' => 'css_animation',
			'admin_label' => true,
			'value' => $animation_opts,
			'description' => __('Select animation type if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Extra class name', 'Twoot'),
			'param_name' => 'el_class',
			'description' => __('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'Twoot')
		)
	)
) );


// Quick Buttons
// Br
vc_map( array(
	'name' => __('Br', 'Twoot'),
	'base' => 'br',
	'icon' => '',
	'category' => __('Quick Buttons', 'Twoot'),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __('Padding Top', 'Twoot'),
			'param_name' => 'top',
			'description' => __('Set the section from top, the unit is pixel.', 'Twoot')
		)
	)
) );


// Clear
vc_map( array(
	'name' => __('Clear', 'Twoot'),
	'base' => 'clear',
	'icon' => '',
	'category' => __('Quick Buttons', 'Twoot'),
	'params' => array()
) );


// Title
vc_map( array(
	'name' => __('Title', 'Twoot'),
	'base' => 'title',
	'icon' => '',
	'category' => __('Quick Buttons', 'Twoot'),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __('Title', 'Twoot'),
			'param_name' => 'content',
			'value' => '',
			'description' => __('Set the title text.', 'Twoot')
		)
	)
) );


// Hr
vc_map( array(
	'name' => __('Hr', 'Twoot'),
	'base' => 'hr',
	'icon' => '',
	'category' => __('Quick Buttons', 'Twoot'),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __('Padding Top', 'Twoot'),
			'param_name' => 'top',
			'description' => __('Set the section from top, the unit is pixel.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Padding Bottom', 'Twoot'),
			'param_name' => 'bottom',
			'description' => __('Set the section from bottom, the unit is pixel.', 'Twoot')
		)
	)
) );


// Accordion
vc_map( array(
	'name' => __('Accordion', 'Twoot'),
	'base' => 'vc_accordion',
	'show_settings_on_create' => false,
	'is_container' => true,
	'icon' => '',
	'category' => __('Content', 'Twoot'),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __('Extra class name', 'Twoot'),
			'param_name' => 'el_class',
			'description' => __('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'Twoot')
		)
		),
		'custom_markup' => '
		<div class="wpb_accordion_holder wpb_holder clearfix vc_container_for_children">
		%content%
		</div>
		<div class="tab_controls">
		<button class="add_tab" title="'.__('Add accordion section', 'Twoot').'">'.__('Add accordion section', 'Twoot').'</button>
		</div>
		',
		'default_content' => '
		[vc_accordion_tab title="'.__('Section 1', 'Twoot').'"][/vc_accordion_tab]
		[vc_accordion_tab title="'.__('Section 2', 'Twoot').'"][/vc_accordion_tab]
		',
		'js_view' => 'VcAccordionView'
	) );
	vc_map( array(
		'name' => __('Accordion Section', 'Twoot'),
		'base' => 'vc_accordion_tab',
		'allowed_container_element' => 'vc_row',
		'is_container' => true,
		'content_element' => false,
		'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __('Title', 'Twoot'),
			'param_name' => 'title',
			'description' => __('Accordion section title.', 'Twoot')
		),
	),
	'js_view' => 'VcAccordionTabView'
) );


// Audio
vc_map( array(
	'name' => __('Audio', 'Twoot'),
	'base' => 'audio',
	'icon' => '',
	'category' => __('Media', 'Twoot'),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __('Soundcloud Url', 'Twoot'),
			'param_name' => 'soundcloud_url',
			'description' => __('The url of audio, it is from SoundCloud. ex: "http://api.soundcloud.com/tracks/100556971"', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Height', 'Twoot'),
			'param_name' => 'height',
			'value' => '166',
			'description' => __('The height for the soundcloud.', 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Embed', 'Twoot'),
			'param_name' => 'embed',
			'description' => __('If you want to add some other embed code, you can use this option.', 'Twoot')
		)
	)
) );


// Blog
vc_map( array(
	'name' => __('Blog', 'Twoot'),
	'base' => 'blog',
	'icon' => '',
	'category' => __('Blog', 'Twoot'),
	'params' => array(
		array(
			'type' => 'dropdown',
			'heading' => __('Tax', 'Twoot'),
			'param_name' => 'tax',
			'value' => $tax_opts,
			'description' => __('The taxonomy for the posts.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Counts', 'Twoot'),
			'param_name' => 'counts',
			'value' => '12',
			'description' => __('The number of posts to display on each page.', 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Cats', 'Twoot'),
			'param_name' => 'cats',
			'description' => __("The category ID's to pull posts from. Can be entered as a comma separated list.", 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Posts', 'Twoot'),
			'param_name' => 'posts',
			'description' => __("The post ID's to pull posts from. Can be entered as a comma separated list.", 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Order', 'Twoot'),
			'param_name' => 'order',
			'value' => $order_opts,
			'description' => __('Designates the ascending or descending order of the "orderby" parameter.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Orderby', 'Twoot'),
			'param_name' => 'orderby',
			'value' => $orderby_opts,
			'description' => __('Sort retrieved posts by parameter.', 'Twoot')
		)
	)
) );


// Blog Carousel
vc_map( array(
	'name' => __('Blog Carousel', 'Twoot'),
	'base' => 'blog_carousel',
	'icon' => '',
	'category' => __('Blog', 'Twoot'),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __('Title', 'Twoot'),
			'param_name' => 'title',
			'value' => 'Recent News',
			'description' => __('The title for the post carousel.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Tax', 'Twoot'),
			'param_name' => 'tax',
			'value' => $tax_opts,
			'description' => __('The taxonomy for the posts.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Counts', 'Twoot'),
			'param_name' => 'counts',
			'value' => '12',
			'description' => __('The number of posts to display on each page.', 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Cats', 'Twoot'),
			'param_name' => 'cats',
			'description' => __("The category ID's to pull posts from. Can be entered as a comma separated list.", 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Posts', 'Twoot'),
			'param_name' => 'posts',
			'description' => __("The post ID's to pull posts from. Can be entered as a comma separated list.", 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Order', 'Twoot'),
			'param_name' => 'order',
			'value' => $order_opts,
			'description' => __('Designates the ascending or descending order of the "orderby" parameter.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Orderby', 'Twoot'),
			'param_name' => 'orderby',
			'value' => $orderby_opts,
			'description' => __('Sort retrieved posts by parameter.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Auto', 'Twoot'),
			'param_name' => 'auto',
			'value' => array(
				__('True', 'Twoot') => 'true',
				__('False', 'Twoot') => 'false'
			),
			'description' => __('(Optional) Auto play the slider (true/false).', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Speed', 'Twoot'),
			'param_name' => 'speed',
			'value' => '800',
			'description' => __('(Optional) Slide transition duration (in ms).', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Pause', 'Twoot'),
			'param_name' => 'pause',
			'value' => '5000',
			'description' => __('(Optional) The amount of time (in ms) between each auto transition.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Move Slides', 'Twoot'),
			'param_name' => 'move_slides',
			'value' => $slider_num_opts,
			'description' => __('(Optional) The number of slides to move on transition.', 'Twoot')
		)
	)
) );


// Blog Grid
vc_map( array(
	'name' => __('Blog Grid', 'Twoot'),
	'base' => 'blog_grid',
	'icon' => '',
	'category' => __('Blog', 'Twoot'),
	'params' => array(
		array(
			'type' => 'dropdown',
			'heading' => __('Tax', 'Twoot'),
			'param_name' => 'tax',
			'value' => $tax_opts,
			'description' => __('The taxonomy for the posts.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Columns', 'Twoot'),
			'param_name' => 'columns',
			'value' => $column_opts,
			'description' => __('(Optional)The number of columns.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Counts', 'Twoot'),
			'param_name' => 'counts',
			'value' => '12',
			'description' => __('(Optional)The number of posts to display on each page.', 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Cats', 'Twoot'),
			'param_name' => 'cats',
			'description' => __("(Optional)The category ID's to pull posts from. Can be entered as a comma separated list.", 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Posts', 'Twoot'),
			'param_name' => 'posts',
			'description' => __("(Optional) The post ID's to pull posts from. Can be entered as a comma separated list.", 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Order', 'Twoot'),
			'param_name' => 'order',
			'value' => $order_opts,
			'description' => __('(Optional) Designates the ascending or descending order of the "orderby" parameter.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Orderby', 'Twoot'),
			'param_name' => 'orderby',
			'value' => $orderby_opts,
			'description' => __('(Optional) Sort retrieved posts by parameter.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Filter', 'Twoot'),
			'param_name' => 'filter',
			'value' => array(
				__('Yes', 'Twoot') => 'yes',
				__('No', 'Twoot') => 'no'
			),
			'description' => __('(Optional) Show the sort menu.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Paging', 'Twoot'),
			'param_name' => 'paging',
			'value' => array(
				__('Yes', 'Twoot') => 'yes',
				__('No', 'Twoot') => 'no'
			),
			'description' => __('(Optional) Show the paging.', 'Twoot')
		)
	)
) );


// Blog List
vc_map( array(
	'name' => __('Blog List', 'Twoot'),
	'base' => 'blog_list',
	'icon' => '',
	'category' => __('Blog', 'Twoot'),
	'params' => array(
		array(
			'type' => 'dropdown',
			'heading' => __('Tax', 'Twoot'),
			'param_name' => 'tax',
			'value' => $tax_opts,
			'description' => __('The taxonomy for the posts.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Columns', 'Twoot'),
			'param_name' => 'columns',
			'value' => $column_opts,
			'description' => __('(Optional)The number of columns.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Counts', 'Twoot'),
			'param_name' => 'counts',
			'value' => '12',
			'description' => __('(Optional)The number of posts to display on each page.', 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Cats', 'Twoot'),
			'param_name' => 'cats',
			'description' => __("(Optional)The category ID's to pull posts from. Can be entered as a comma separated list.", 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Posts', 'Twoot'),
			'param_name' => 'posts',
			'description' => __("(Optional) The post ID's to pull posts from. Can be entered as a comma separated list.", 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Order', 'Twoot'),
			'param_name' => 'order',
			'value' => $order_opts,
			'description' => __('(Optional) Designates the ascending or descending order of the "orderby" parameter.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Orderby', 'Twoot'),
			'param_name' => 'orderby',
			'value' => $orderby_opts,
			'description' => __('(Optional) Sort retrieved posts by parameter.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Paging', 'Twoot'),
			'param_name' => 'paging',
			'value' => array(
				__('Yes', 'Twoot') => 'yes',
				__('No', 'Twoot') => 'no'
			),
			'description' => __('(Optional) Show the paging.', 'Twoot')
		)
	)
) );


// Blog Masonry
vc_map( array(
	'name' => __('Blog Masonry', 'Twoot'),
	'base' => 'blog_masonry',
	'icon' => '',
	'category' => __('Blog', 'Twoot'),
	'params' => array(
		array(
			'type' => 'dropdown',
			'heading' => __('Tax', 'Twoot'),
			'param_name' => 'tax',
			'value' => $tax_opts,
			'description' => __('The taxonomy for the posts.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Columns', 'Twoot'),
			'param_name' => 'columns',
			'value' => $column_opts,
			'description' => __('(Optional)The number of columns.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Counts', 'Twoot'),
			'param_name' => 'counts',
			'value' => '12',
			'description' => __('(Optional)The number of posts to display on each page.', 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Cats', 'Twoot'),
			'param_name' => 'cats',
			'description' => __("(Optional)The category ID's to pull posts from. Can be entered as a comma separated list.", 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Posts', 'Twoot'),
			'param_name' => 'posts',
			'description' => __("(Optional) The post ID's to pull posts from. Can be entered as a comma separated list.", 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Order', 'Twoot'),
			'param_name' => 'order',
			'value' => $order_opts,
			'description' => __('(Optional) Designates the ascending or descending order of the "orderby" parameter.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Orderby', 'Twoot'),
			'param_name' => 'orderby',
			'value' => $orderby_opts,
			'description' => __('(Optional) Sort retrieved posts by parameter.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Filter', 'Twoot'),
			'param_name' => 'filter',
			'value' => array(
				__('Yes', 'Twoot') => 'yes',
				__('No', 'Twoot') => 'no'
			),
			'description' => __('(Optional) Show the sort menu.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Paging', 'Twoot'),
			'param_name' => 'paging',
			'value' => array(
				__('Yes', 'Twoot') => 'yes',
				__('No', 'Twoot') => 'no'
			),
			'description' => __('(Optional) Show the paging.', 'Twoot')
		)
	)
) );


// Button
vc_map( array(
	'name' => __('Button', 'Twoot'),
	'base' => 'button',
	'icon' => '',
	'category' => __('Content', 'Twoot'),
	'params' => array(
		array(
			'type' => 'dropdown',
			'heading' => __('Style', 'Twoot'),
			'param_name' => 'style',
			'value' => array(
				__('Dark', 'Twoot') => 'dark',
				__('Light', 'Twoot') => 'light',
				__('Blue', 'Twoot') => 'blue',
				__('Red', 'Twoot') => 'red',
				__('Yellow', 'Twoot') => 'yellow',
				__('Green', 'Twoot') => 'green'
			),
			'description' => __('The style for button.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Type', 'Twoot'),
			'param_name' => 'type',
			'value' => array(
				__('None', 'Twoot') => 'none',
				__('Border', 'Twoot') => 'border'
			),
			'description' => __('The type for button.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Size', 'Twoot'),
			'param_name' => 'size',
			'value' => array(
				__('Small', 'Twoot') => 'small',
				__('Medium', 'Twoot') => 'medium',
				__('Large', 'Twoot') => 'large'
			),
			'description' => __('The size for button.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Link', 'Twoot'),
			'param_name' => 'link',
			'description' => __('Enter the link url that you want to go.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Target', 'Twoot'),
			'param_name' => 'target',
			'value' => array(
				__('Self', 'Twoot') => 'self',
				__('Blank', 'Twoot') => 'blank'
			),
			'description' => __('(Optional) The target for button.', 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Button text', 'Twoot'),
			'param_name' => 'content',
			'value' => __('Button Text', 'Twoot')
		)
	)
) );


// Column
vc_map( array(
	'name' => __('Column', 'Twoot'),
	'base' => 'vc_column',
	'is_container' => true,
	'content_element' => false,
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __('Padding Top', 'Twoot'),
			'param_name' => 'pt',
			'description' => __('Set the section from top, the unit is pixel.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Padding Bottom', 'Twoot'),
			'param_name' => 'pb',
			'description' => __('Set the section from bottom, the unit is pixel.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('CSS Animation', 'Twoot'),
			'param_name' => 'css_animation',
			'admin_label' => true,
			'value' => $animation_opts,
			'description' => __('Select animation type if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Extra class name', 'Twoot'),
			'param_name' => 'el_class',
			'description' => __('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'Twoot')
		)
	),
	'js_view' => 'VcColumnView'
) );


// Column Inner
vc_map( array(
	'name' => __('Column', 'Twoot'),
	'base' => 'vc_column_inner',
	'class' => '',
	'icon' => '',
	'wrapper_class' => '',
	'controls'	=> 'full',
	'allowed_container_element' => false,
	'content_element' => false,
	'is_container' => true,
	'params'=> array(
		array(
			'type' => 'textfield',
			'heading' => __('Padding Top', 'Twoot'),
			'param_name' => 'pt',
			'description' => __('Set the section from top, the unit is pixel.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Padding Bottom', 'Twoot'),
			'param_name' => 'pb',
			'description' => __('Set the section from bottom, the unit is pixel.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('CSS Animation', 'Twoot'),
			'param_name' => 'css_animation',
			'admin_label' => true,
			'value' => $animation_opts,
			'description' => __('Select animation type if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.', 'Twoot')
		),
		array(
		  'type' => 'textfield',
		  'heading' => __('Extra class name', 'Twoot'),
		  'param_name' => 'el_class',
		  'value' => '',
		  'description' => __('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'Twoot')
		)
	),
	'js_view' => 'VcColumnView'
) );


// FAQs
vc_map( array(
	'name' => __('FAQs', 'Twoot'),
	'base' => 'faqs',
	'icon' => '',
	'category' => __('Content', 'Twoot'),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __('Counts', 'Twoot'),
			'param_name' => 'counts',
			'value' => '12',
			'description' => __('(Optional)The number of posts to display on each page.', 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Cats', 'Twoot'),
			'param_name' => 'cats',
			'description' => __("(Optional)The category ID's to pull posts from. Can be entered as a comma separated list.", 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Posts', 'Twoot'),
			'param_name' => 'posts',
			'description' => __("(Optional) The post ID's to pull posts from. Can be entered as a comma separated list.", 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Order', 'Twoot'),
			'param_name' => 'order',
			'value' => $order_opts,
			'description' => __('(Optional) Designates the ascending or descending order of the "orderby" parameter.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Orderby', 'Twoot'),
			'param_name' => 'orderby',
			'value' => $orderby_opts,
			'description' => __('(Optional) Sort retrieved posts by parameter.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Filter', 'Twoot'),
			'param_name' => 'filter',
			'value' => array(
				__('Yes', 'Twoot') => 'yes',
				__('No', 'Twoot') => 'no'
			),
			'description' => __('(Optional) Show the sort menu.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Paging', 'Twoot'),
			'param_name' => 'paging',
			'value' => array(
				__('Yes', 'Twoot') => 'yes',
				__('No', 'Twoot') => 'no'
			),
			'description' => __('(Optional) Show the paging.', 'Twoot')
		)
	)
) );


// Feature Service 
vc_map( array(
	'name' => __('Feature Service', 'Twoot'),
	'base' => 'feature_service',
	'icon' => '',
	'category' => __('Content', 'Twoot'),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __('Title', 'Twoot'),
			'param_name' => 'title',
			'description' => __('Enter your title.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Icon', 'Twoot'),
			'param_name' => 'icon',
			'description' => __('Enter the icon name. You can find the icon name here:<a href="'. get_template_directory_uri() . '/fonts/" target="_blank">Link</a>', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Link', 'Twoot'),
			'param_name' => 'link',
			'description' => __('Enter the link url that you want to go.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Button Text', 'Twoot'),
			'param_name' => 'button_text',
			'description' => __('Enter the button text.', 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Message text', 'Twoot'),
			'param_name' => 'content',
			'value' => __('I am message box. Click edit button to change this text.', 'Twoot')
		)
	)
) );


// Google Map 
vc_map( array(
	'name' => __('Google Map', 'Twoot'),
	'base' => 'gmap',
	'icon' => '',
	'category' => __('Content', 'Twoot'),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __('Address', 'Twoot'),
			'param_name' => 'address',
			'description' => __('The place you want to show.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Lat', 'Twoot'),
			'param_name' => 'lat',
			'description' => __('(Optional) The number of map lat.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Lng', 'Twoot'),
			'param_name' => 'lng',
			'description' => __('(Optional) The number of map lng.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Zoom', 'Twoot'),
			'param_name' => 'zoom',
			'value' => '14',
			'description' => __('(Optional) The number of map zoom.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Height', 'Twoot'),
			'param_name' => 'height',
			'value' => '500',
			'description' => __('(Optional) The number of map height.', 'Twoot')
		)
	)
) );


// Hgroup
vc_map( array(
	'name' => __('Hgroup', 'Twoot'),
	'base' => 'hgroup',
	'icon' => '',
	'category' => __('Content', 'Twoot'),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __('Margin Top', 'Twoot'),
			'param_name' => 'mt',
			'description' => __('Set the section from top, the unit is pixel.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Margin Bottom', 'Twoot'),
			'param_name' => 'mb',
			'description' => __('Set the section from bottom, the unit is pixel.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Tag', 'Twoot'),
			'param_name' => 'tag',
			'value' => array(
				__('H1', 'Twoot') => 'h1',
				__('H2', 'Twoot') => 'h2',
				__('H3', 'Twoot') => 'h3',
				__('H4', 'Twoot') => 'h4',
				__('H5', 'Twoot') => 'h5',
				__('H6', 'Twoot') => 'h6'
			),
			'description' => __('Enter your title.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Font Family', 'Twoot'),
			'param_name' => 'font_family',
			'description' => __('Set the font family.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Font Size', 'Twoot'),
			'param_name' => 'font_size',
			'description' => __('Set the font size.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Font Weight', 'Twoot'),
			'param_name' => 'font_weight',
			'value' => array(
				__('Normal', 'Twoot') => 'normal',
				__('Bold', 'Twoot') => 'bold'
			),
			'description' => __('Set the font weight.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Text Transform', 'Twoot'),
			'param_name' => 'text_transform',
			'value' => array(
				__('None', 'Twoot') => 'none',
				__('Capitalize', 'Twoot') => 'capitalize',
				__('Uppercase', 'Twoot') => 'uppercase',
				__('Lowercase', 'Twoot') => 'lowercase'
			),
			'description' => __('Set the text transform.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Text Align', 'Twoot'),
			'param_name' => 'text_align',
			'value' => array(
				__('Left', 'Twoot') => 'left',
				__('Center', 'Twoot') => 'center',
				__('Right', 'Twoot') => 'right'
			),
			'description' => __('Set the text align.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Text Color', 'Twoot'),
			'param_name' => 'text_color',
			'description' => __('Set the section text color, ex: "#FFFFFF".', 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Text', 'Twoot'),
			'param_name' => 'content',
			'value' => __('', 'Twoot')
		)
	)
) );


// Icon
vc_map( array(
	'name' => __('Icon', 'Twoot'),
	'base' => 'icon',
	'icon' => '',
	'category' => __('Content', 'Twoot'),
	'params' => array(
		array(
			'type' => 'dropdown',
			'heading' => __('Size', 'Twoot'),
			'param_name' => 'size',
			'value' => array(
				__('Small', 'Twoot') => 'small',
				__('Medium', 'Twoot') => 'medium',
				__('Large', 'Twoot') => 'large'
			),
			'description' => __('The size for button.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Name', 'Twoot'),
			'param_name' => 'name',
			'description' => __('Enter the icon name. You can find the icon name here:<a href="'. get_template_directory_uri() . '/fonts/" target="_blank">Link</a>', 'Twoot')
		)
	)
) );


// Icon Boxes
vc_map( array(
	'name' => __('Icon Boxes', 'Twoot'),
	'base' => 'icon_box',
	'icon' => '',
	'category' => __('Content', 'Twoot'),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __('Title', 'Twoot'),
			'param_name' => 'title',
			'description' => __('Enter your title.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Icon', 'Twoot'),
			'param_name' => 'icon',
			'description' => __('Enter the icon name. You can find the icon name here:<a href="'. get_template_directory_uri() . '/fonts/" target="_blank">Link</a>', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Link', 'Twoot'),
			'param_name' => 'link',
			'description' => __('Enter the link url that you want to go.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Button Text', 'Twoot'),
			'param_name' => 'button_text',
			'description' => __('Enter the button text.', 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Message text', 'Twoot'),
			'param_name' => 'content',
			'value' => __('I am message box. Click edit button to change this text.', 'Twoot')
		)
	)
) );


// Image
vc_map( array(
	'name' => __('Image', 'Twoot'),
	'base' => 'vc_image',
	'icon' => '',
	'category' => __('Content', 'Twoot'),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __('Title', 'Twoot'),
			'param_name' => 'title',
			'description' => __('(Optional) The title of image.', 'Twoot')
		),
		array(
			'type' => 'attach_image',
			'heading' => __('Image', 'Twoot'),
			'param_name' => 'id',
			'value' => '',
			'description' => __('The image id.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Width', 'Twoot'),
			'param_name' => 'width',
			'description' => __('(Optional) The image width.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Height', 'Twoot'),
			'param_name' => 'height',
			'description' => __('(Optional) The image height.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Crop', 'Twoot'),
			'param_name' => 'crop',
			'value' => array(
				__('Yes', 'Twoot') => 'yes',
				__('No', 'Twoot') => 'no'
			),
			'description' => __('(Optional) Crop the image or not.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Link', 'Twoot'),
			'param_name' => 'link',
			'description' => __('(Optional) The link of image.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Lightbox', 'Twoot'),
			'param_name' => 'lightbox',
			'value' => array(
				__('Yes', 'Twoot') => 'yes',
				__('No', 'Twoot') => 'no'
			),
			'description' => __('(Optional) Show the image with lightbox or not.', 'Twoot')
		)
	)
) );


// Message Boxes
vc_map( array(
	'name' => __('Message Boxes', 'Twoot'),
	'base' => 'message_box',
	'icon' => '',
	'category' => __('Content', 'Twoot'),
	'params' => array(
		array(
			'type' => 'dropdown',
			'heading' => __('Style', 'Twoot'),
			'param_name' => 'style',
			'value' => array(
				__('Default', 'Twoot') => 'default',
				__('Success', 'Twoot') => 'success',
				__('Warning', 'Twoot') => 'warning',
				__('Notice', 'Twoot') => 'notice',
				__('Error', 'Twoot') => 'error'
			),
			'description' => __('Choose the style.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Close', 'Twoot'),
			'param_name' => 'close',
			'value' => array(
				__('Yes', 'Twoot') => 'yes',
				__('No', 'Twoot') => 'no'
			),
			'description' => __('Show the close button.', 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Text', 'Twoot'),
			'param_name' => 'content',
			'value' => __('I am message box. Click edit button to change this text.', 'Twoot')
		)
	)
) );


// Number
vc_map( array(
	'name' => __('Number', 'Twoot'),
	'base' => 'number',
	'icon' => '',
	'category' => __('Content', 'Twoot'),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __('Icon', 'Twoot'),
			'param_name' => 'icon',
			'description' => __('Enter the icon name.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Title', 'Twoot'),
			'param_name' => 'title',
			'description' => __('Enter your title.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Percent', 'Twoot'),
			'param_name' => 'percent',
			'description' => __('Enter the percent.', 'Twoot')
		)
	)
) );


// Latest Blog
vc_map( array(
	'name' => __('Latest Blog', 'Twoot'),
	'base' => 'latest_blog',
	'icon' => '',
	'category' => __('Blog', 'Twoot'),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __('Counts', 'Twoot'),
			'param_name' => 'counts',
			'value' => '5',
			'description' => __('The number of posts to display on each page.', 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Cats', 'Twoot'),
			'param_name' => 'cats',
			'description' => __("The category ID's to pull posts from. Can be entered as a comma separated list.", 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Posts', 'Twoot'),
			'param_name' => 'posts',
			'description' => __("The post ID's to pull posts from. Can be entered as a comma separated list.", 'Twoot')
		)
	)
) );


// Portfolio Carousel
vc_map( array(
	'name' => __('Portfolio Carousel', 'Twoot'),
	'base' => 'portfolio_carousel',
	'icon' => '',
	'category' => __('Portfolio', 'Twoot'),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __('Title', 'Twoot'),
			'param_name' => 'title',
			'value' => 'Recent Works',
			'description' => __('The title for the post carousel.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Tax', 'Twoot'),
			'param_name' => 'tax',
			'value' => $tax_opts,
			'description' => __('The taxonomy for the posts.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Counts', 'Twoot'),
			'param_name' => 'counts',
			'value' => '12',
			'description' => __('The number of posts to display on each page.', 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Cats', 'Twoot'),
			'param_name' => 'cats',
			'description' => __("The category ID's to pull posts from. Can be entered as a comma separated list.", 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Posts', 'Twoot'),
			'param_name' => 'posts',
			'description' => __("The post ID's to pull posts from. Can be entered as a comma separated list.", 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Order', 'Twoot'),
			'param_name' => 'order',
			'value' => $order_opts,
			'description' => __('Designates the ascending or descending order of the "orderby" parameter.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Orderby', 'Twoot'),
			'param_name' => 'orderby',
			'value' => $orderby_opts,
			'description' => __('Sort retrieved posts by parameter.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Auto', 'Twoot'),
			'param_name' => 'auto',
			'value' => array(
				__('True', 'Twoot') => 'true',
				__('False', 'Twoot') => 'false'
			),
			'description' => __('(Optional) Auto play the slider (true/false).', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Speed', 'Twoot'),
			'param_name' => 'speed',
			'value' => '800',
			'description' => __('(Optional) Slide transition duration (in ms).', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Pause', 'Twoot'),
			'param_name' => 'pause',
			'value' => '5000',
			'description' => __('(Optional) The amount of time (in ms) between each auto transition.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Move Slides', 'Twoot'),
			'param_name' => 'move_slides',
			'value' => $slider_num_opts,
			'description' => __('(Optional) The number of slides to move on transition.', 'Twoot')
		)
	)
) );


// Portfolio Grid
vc_map( array(
	'name' => __('Portfolio Grid', 'Twoot'),
	'base' => 'portfolio_grid',
	'icon' => '',
	'category' => __('Portfolio', 'Twoot'),
	'params' => array(
		array(
			'type' => 'dropdown',
			'heading' => __('Tax', 'Twoot'),
			'param_name' => 'tax',
			'value' => $tax_opts,
			'description' => __('The taxonomy for the posts.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Columns', 'Twoot'),
			'param_name' => 'columns',
			'value' => $column_opts,
			'description' => __('(Optional)The number of columns.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Counts', 'Twoot'),
			'param_name' => 'counts',
			'value' => '12',
			'description' => __('(Optional)The number of posts to display on each page.', 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Cats', 'Twoot'),
			'param_name' => 'cats',
			'description' => __("(Optional)The category ID's to pull posts from. Can be entered as a comma separated list.", 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Posts', 'Twoot'),
			'param_name' => 'posts',
			'description' => __("(Optional) The post ID's to pull posts from. Can be entered as a comma separated list.", 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Order', 'Twoot'),
			'param_name' => 'order',
			'value' => $order_opts,
			'description' => __('(Optional) Designates the ascending or descending order of the "orderby" parameter.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Orderby', 'Twoot'),
			'param_name' => 'orderby',
			'value' => $orderby_opts,
			'description' => __('(Optional) Sort retrieved posts by parameter.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Filter', 'Twoot'),
			'param_name' => 'filter',
			'value' => array(
				__('Yes', 'Twoot') => 'yes',
				__('No', 'Twoot') => 'no'
			),
			'description' => __('(Optional) Show the sort menu.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Paging', 'Twoot'),
			'param_name' => 'paging',
			'value' => array(
				__('Yes', 'Twoot') => 'yes',
				__('No', 'Twoot') => 'no'
			),
			'description' => __('(Optional) Show the paging.', 'Twoot')
		)
	)
) );


// Portfolio List
vc_map( array(
	'name' => __('Portfolio List', 'Twoot'),
	'base' => 'portfolio_list',
	'icon' => '',
	'category' => __('Portfolio', 'Twoot'),
	'params' => array(
		array(
			'type' => 'dropdown',
			'heading' => __('Tax', 'Twoot'),
			'param_name' => 'tax',
			'value' => $tax_opts,
			'description' => __('The taxonomy for the posts.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Columns', 'Twoot'),
			'param_name' => 'columns',
			'value' => $column_opts,
			'description' => __('The number of columns.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Counts', 'Twoot'),
			'param_name' => 'counts',
			'value' => '12',
			'description' => __('The number of posts to display on each page.', 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Cats', 'Twoot'),
			'param_name' => 'cats',
			'description' => __("The category ID's to pull posts from. Can be entered as a comma separated list.", 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Posts', 'Twoot'),
			'param_name' => 'posts',
			'description' => __("The post ID's to pull posts from. Can be entered as a comma separated list.", 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Order', 'Twoot'),
			'param_name' => 'order',
			'value' => $order_opts,
			'description' => __('Designates the ascending or descending order of the "orderby" parameter.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Orderby', 'Twoot'),
			'param_name' => 'orderby',
			'value' => $orderby_opts,
			'description' => __('Sort retrieved posts by parameter.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Paging', 'Twoot'),
			'param_name' => 'paging',
			'value' => array(
				__('Yes', 'Twoot') => 'yes',
				__('No', 'Twoot') => 'no'
			),
			'description' => __('Show the paging.', 'Twoot')
		)
	)
) );


// Portfolio Masonry
vc_map( array(
	'name' => __('Portfolio Masonry', 'Twoot'),
	'base' => 'portfolio_masonry',
	'icon' => '',
	'category' => __('Portfolio', 'Twoot'),
	'params' => array(
		array(
			'type' => 'dropdown',
			'heading' => __('Tax', 'Twoot'),
			'param_name' => 'tax',
			'value' => $tax_opts,
			'description' => __('The taxonomy for the posts.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Columns', 'Twoot'),
			'param_name' => 'columns',
			'value' => $column_opts,
			'description' => __('(Optional)The number of columns.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Counts', 'Twoot'),
			'param_name' => 'counts',
			'value' => '12',
			'description' => __('(Optional)The number of posts to display on each page.', 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Cats', 'Twoot'),
			'param_name' => 'cats',
			'description' => __("(Optional)The category ID's to pull posts from. Can be entered as a comma separated list.", 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Posts', 'Twoot'),
			'param_name' => 'posts',
			'description' => __("(Optional) The post ID's to pull posts from. Can be entered as a comma separated list.", 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Order', 'Twoot'),
			'param_name' => 'order',
			'value' => $order_opts,
			'description' => __('(Optional) Designates the ascending or descending order of the "orderby" parameter.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Orderby', 'Twoot'),
			'param_name' => 'orderby',
			'value' => $orderby_opts,
			'description' => __('(Optional) Sort retrieved posts by parameter.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Filter', 'Twoot'),
			'param_name' => 'filter',
			'value' => array(
				__('Yes', 'Twoot') => 'yes',
				__('No', 'Twoot') => 'no'
			),
			'description' => __('(Optional) Show the sort menu.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Paging', 'Twoot'),
			'param_name' => 'paging',
			'value' => array(
				__('Yes', 'Twoot') => 'yes',
				__('No', 'Twoot') => 'no'
			),
			'description' => __('(Optional) Show the paging.', 'Twoot')
		)
	)
) );


// Post Images
vc_map( array(
	'name' => __('Post Images', 'Twoot'),
	'base' => 'post_images',
	'icon' => '',
	'category' => __('Content', 'Twoot'),
	'params' => array(
		array(
			'type' => 'attach_images',
			'heading' => __('Images', 'Twoot'),
			'param_name' => 'ids',
			'value' => '',
			'description' => __('The image ids.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Width', 'Twoot'),
			'param_name' => 'width',
			'description' => __('(Optional) The image width.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Height', 'Twoot'),
			'param_name' => 'height',
			'description' => __('(Optional) The image height.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Crop', 'Twoot'),
			'param_name' => 'crop',
			'value' => array(
				__('Yes', 'Twoot') => 'yes',
				__('No', 'Twoot') => 'no'
			),
			'description' => __('(Optional) Crop the image or not.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Lightbox', 'Twoot'),
			'param_name' => 'lightbox',
			'value' => array(
				__('Yes', 'Twoot') => 'yes',
				__('No', 'Twoot') => 'no'
			),
			'description' => __('(Optional) Show the image with lightbox or not.', 'Twoot')
		)
	)
) );


// Post Masonry
vc_map( array(
	'name' => __('Post Masonry', 'Twoot'),
	'base' => 'post_masonry',
	'icon' => '',
	'category' => __('Content', 'Twoot'),
	'params' => array(
		array(
			'type' => 'attach_images',
			'heading' => __('Images', 'Twoot'),
			'param_name' => 'ids',
			'value' => '',
			'description' => __('The image ids.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Width', 'Twoot'),
			'param_name' => 'width',
			'description' => __('(Optional) The image width.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Height', 'Twoot'),
			'param_name' => 'height',
			'description' => __('(Optional) The image height.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Crop', 'Twoot'),
			'param_name' => 'crop',
			'value' => array(
				__('Yes', 'Twoot') => 'yes',
				__('No', 'Twoot') => 'no'
			),
			'description' => __('(Optional) Crop the image or not.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Lightbox', 'Twoot'),
			'param_name' => 'lightbox',
			'value' => array(
				__('Yes', 'Twoot') => 'yes',
				__('No', 'Twoot') => 'no'
			),
			'description' => __('(Optional) Show the image with lightbox or not.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Columns', 'Twoot'),
			'param_name' => 'columns',
			'value' => $column_opts,
			'description' => __('(Optional)The number of columns.', 'Twoot')
		)
	)
) );


// Post Slider
vc_map( array(
	'name' => __('Post Slider', 'Twoot'),
	'base' => 'post_slider',
	'icon' => '',
	'category' => __('Content', 'Twoot'),
	'params' => array(
		array(
			'type' => 'attach_images',
			'heading' => __('Images', 'Twoot'),
			'param_name' => 'ids',
			'value' => '',
			'description' => __('The image ids.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Width', 'Twoot'),
			'param_name' => 'width',
			'description' => __('(Optional) The image width.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Height', 'Twoot'),
			'param_name' => 'height',
			'description' => __('(Optional) The image height.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Crop', 'Twoot'),
			'param_name' => 'crop',
			'value' => array(
				__('Yes', 'Twoot') => 'yes',
				__('No', 'Twoot') => 'no'
			),
			'description' => __('(Optional) Crop the image or not.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Lightbox', 'Twoot'),
			'param_name' => 'lightbox',
			'value' => array(
				__('Yes', 'Twoot') => 'yes',
				__('No', 'Twoot') => 'no'
			),
			'description' => __('(Optional) Show the image with lightbox or not.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Auto', 'Twoot'),
			'param_name' => 'auto',
			'value' => array(
				__('True', 'Twoot') => 'true',
				__('False', 'Twoot') => 'false'
			),
			'description' => __('(Optional) Auto play the slider (true/false).', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Speed', 'Twoot'),
			'param_name' => 'speed',
			'value' => '800',
			'description' => __('(Optional) Slide transition duration (in ms).', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Pause', 'Twoot'),
			'param_name' => 'pause',
			'value' => '5000',
			'description' => __('(Optional) The amount of time (in ms) between each auto transition.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Mode', 'Twoot'),
			'param_name' => 'mode',
			'value' => array(
				__('Fade', 'Twoot') => 'fade',
				__('Horizontal', 'Twoot') => 'horizontal',
				__('Vertical', 'Twoot') => 'vertical'
			),
			'description' => __('Type of transition between slides.', 'Twoot')
		)
	)
) );


// Price Table
vc_map( array(
	'name' => __('Price Table', 'Twoot'),
	'base' => 'price_table',
	'icon' => '',
	'category' => __('Content', 'Twoot'),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __('Title', 'Twoot'),
			'param_name' => 'title',
			'description' => __('The title for price table.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Currency', 'Twoot'),
			'param_name' => 'currency',
			'value' => '$',
			'description' => __('The currency for price table.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Price', 'Twoot'),
			'param_name' => 'price',
			'description' => __('The price for price table.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Sub Price', 'Twoot'),
			'param_name' => 'sub_price',
			'description' => __('The sub price for price table.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Time', 'Twoot'),
			'param_name' => 'time',
			'description' => __('The time for price table.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Button Text', 'Twoot'),
			'param_name' => 'button_text',
			'description' => __('Enter the button text.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Button Link', 'Twoot'),
			'param_name' => 'button_link',
			'description' => __('Enter the link url that you want to go.', 'Twoot')
		),
		array(
			'type' => 'textarea_html',
			'holder' => 'div',
			'heading' => __('Text', 'Twoot'),
			'param_name' => 'content',
			'value' => __('I am text block. Click edit button to change this text.', 'Twoot')
		)
	)
) );


// Progress Bar
vc_map( array(
	'name' => __('Progress Bar', 'Twoot'),
	'base' => 'progress_bar',
	'icon' => '',
	'category' => __('Content', 'Twoot'),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __('Title', 'Twoot'),
			'param_name' => 'title',
			'description' => __('Enter your title.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Percent', 'Twoot'),
			'param_name' => 'percent',
			'description' => __('Enter the percent.', 'Twoot')
		)
	)
) );


// Social Icon
vc_map( array(
	'name' => __('Social Icon', 'Twoot'),
	'base' => 'social_icon',
	'icon' => '',
	'category' => __('Content', 'Twoot'),
	'params' => array(
		array(
			'type' => 'dropdown',
			'heading' => __('Type', 'Twoot'),
			'param_name' => 'type',
			'value' => array(
				__('Duckduckgo', 'Twoot') => 'duckduckgo',
				__('Aim', 'Twoot') => 'aim',
				__('Delicious', 'Twoot') => 'delicious',
				__('Smashmag', 'Twoot') => 'smashmag',
				__('Fivehundredpx', 'Twoot') => 'fivehundredpx',
				__('Forrst', 'Twoot') => 'forrst',
				__('Blogger', 'Twoot') => 'blogger',
				__('Viadeo', 'Twoot') => 'viadeo',
				__('Youtube', 'Twoot') => 'youtube',
				__('Facebook', 'Twoot') => 'facebook',
				__('Github', 'Twoot') => 'github',
				__('Twitter', 'Twoot') => 'twitter',
				__('Flickr', 'Twoot') => 'flickr',
				__('Vimeo', 'Twoot') => 'vimeo',
				__('Gplus', 'Twoot') => 'gplus',
				__('Pinterest', 'Twoot') => 'pinterest',
				__('Tumblr', 'Twoot') => 'tumblr',
				__('Linkedin', 'Twoot') => 'linkedin',
				__('Dribbble', 'Twoot') => 'dribbble',
				__('Stumbleupon', 'Twoot') => 'stumbleupon',
				__('Box', 'Twoot') => 'box',
				__('Spotify', 'Twoot') => 'spotify',
				__('Instagram', 'Twoot') => 'instagram',
				__('Dropbox', 'Twoot') => 'dropbox',
				__('Flattr', 'Twoot') => 'flattr',
				__('Skype', 'Twoot') => 'skype',
				__('Soundcloud', 'Twoot') => 'soundcloud',
				__('Behance', 'Twoot') => 'behance',
				__('Vkontakte', 'Twoot') => 'vkontakte'
			),
			'description' => __('Type of social icon.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Link', 'Twoot'),
			'param_name' => 'ink',
			'description' => __('Enter the link url that you want to go.', 'Twoot')
		)
	)
) );


// Team Member
vc_map( array(
	'name' => __('Team Member', 'Twoot'),
	'base' => 'team_member',
	'icon' => '',
	'category' => __('Content', 'Twoot'),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __('Avatar', 'Twoot'),
			'param_name' => 'avatar',
			'description' => __('The image url for avatar.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Name', 'Twoot'),
			'param_name' => 'name',
			'description' => __('The name for member.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Role', 'Twoot'),
			'param_name' => 'role',
			'description' => __('The role for member.', 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Text', 'Twoot'),
			'param_name' => 'content',
			'value' => __('I am message box. Click edit button to change this text.', 'Twoot')
		)
	)
) );


// Testimonial
vc_map( array(
	'name' => __('Testimonials', 'Twoot'),
	'base' => 'testimonials',
	'icon' => '',
	'category' => __('Content', 'Twoot'),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __('Counts', 'Twoot'),
			'param_name' => 'counts',
			'value' => '5',
			'description' => __('The number of posts to display on each page.', 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Posts', 'Twoot'),
			'param_name' => 'posts',
			'description' => __("The post ID's to pull posts from. Can be entered as a comma separated list.", 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Order', 'Twoot'),
			'param_name' => 'order',
			'value' => $order_opts,
			'description' => __('Designates the ascending or descending order of the "orderby" parameter.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Orderby', 'Twoot'),
			'param_name' => 'orderby',
			'value' => $orderby_opts,
			'description' => __('Sort retrieved posts by parameter.', 'Twoot')
		)
	)
) );


// Testimonial Carousel
vc_map( array(
	'name' => __('Testimonial Carousel', 'Twoot'),
	'base' => 'testimonial_carousel',
	'icon' => '',
	'category' => __('Content', 'Twoot'),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __('Counts', 'Twoot'),
			'param_name' => 'counts',
			'value' => '12',
			'description' => __('The number of posts to display on each page.', 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Posts', 'Twoot'),
			'param_name' => 'posts',
			'description' => __("The post ID's to pull posts from. Can be entered as a comma separated list.", 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Order', 'Twoot'),
			'param_name' => 'order',
			'value' => $order_opts,
			'description' => __('Designates the ascending or descending order of the "orderby" parameter.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Orderby', 'Twoot'),
			'param_name' => 'orderby',
			'value' => $orderby_opts,
			'description' => __('Sort retrieved posts by parameter.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Auto', 'Twoot'),
			'param_name' => 'auto',
			'value' => array(
				__('True', 'Twoot') => 'true',
				__('False', 'Twoot') => 'false'
			),
			'description' => __('(Optional) Auto play the slider (true/false).', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Speed', 'Twoot'),
			'param_name' => 'speed',
			'value' => '800',
			'description' => __('(Optional) Slide transition duration (in ms).', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Pause', 'Twoot'),
			'param_name' => 'pause',
			'value' => '5000',
			'description' => __('(Optional) The amount of time (in ms) between each auto transition.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Mode', 'Twoot'),
			'param_name' => 'mode',
			'value' => array(
				__('Fade', 'Twoot') => 'fade',
				__('Horizontal', 'Twoot') => 'horizontal',
				__('Vertical', 'Twoot') => 'vertical'
			),
			'description' => __('Type of transition between slides.', 'Twoot')
		)
	)
) );


// Toggle
vc_map( array(
	'name' => __('Toggle', 'Twoot'),
	'base' => 'vc_toggle',
	'icon' => '',
	'category' => __('Content', 'Twoot'),
	'params' => array(
		array(
			'type' => 'textfield',
			'holder' => 'h4',
			'class' => 'toggle_title',
			'heading' => __('Toggle title', 'Twoot'),
			'param_name' => 'title',
			'value' => __('Toggle title', 'Twoot'),
			'description' => __('Toggle block title.', 'Twoot')
		),
		array(
			'type' => 'textarea_html',
			'holder' => 'div',
			'class' => 'toggle_content',
			'heading' => __('Toggle content', 'Twoot'),
			'param_name' => 'content',
			'value' => __('<p>Toggle content goes here, click edit button to change this text.</p>', 'Twoot'),
			'description' => __('Toggle block content.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Extra class name', 'Twoot'),
			'param_name' => 'el_class',
			'description' => __('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'Twoot')
		)
	),
	'js_view' => 'VcToggleView'
) );


// Tabs
$tab_id_1 = time().'-1-'.rand(0, 100);
$tab_id_2 = time().'-2-'.rand(0, 100);
vc_map( array(
	'name'  => __('Tabs', 'Twoot'),
	'base' => 'vc_tabs',
	'show_settings_on_create' => false,
	'is_container' => true,
	'icon' => '',
	'category' => __('Content', 'Twoot'),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __('Extra class name', 'Twoot'),
			'param_name' => 'el_class',
			'description' => __('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'Twoot')
		)
	),
	'custom_markup' => '
	<div class="wpb_tabs_holder wpb_holder vc_container_for_children">
	<ul class="tabs_controls">
	</ul>
	%content%
	</div>'
	,
	'default_content' => '
	[vc_tab title="'.__('Tab 1','Twoot').'" tab_id="'.$tab_id_1.'"][/vc_tab]
	[vc_tab title="'.__('Tab 2','Twoot').'" tab_id="'.$tab_id_2.'"][/vc_tab]
	',
	'js_view' => 'VcTabsView'
) );


vc_map( array(
	'name'  => __('Tour', 'Twoot'),
	'base' => 'vc_tour',
	'show_settings_on_create' => false,
	'is_container' => true,
	'icon' => '',
	'category' => __('Content', 'Twoot'),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __('Extra class name', 'Twoot'),
			'param_name' => 'el_class',
			'description' => __('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'Twoot')
		)
	),
	'custom_markup' => '
	<div class="wpb_tabs_holder wpb_holder vc_container_for_children">
	<ul class="tabs_controls">
	</ul>
	%content%
	</div>'
	,
	'default_content' => '
	[vc_tab title="'.__('Tab 1','Twoot').'" tab_id="'.$tab_id_1.'"][/vc_tab]
	[vc_tab title="'.__('Tab 2','Twoot').'" tab_id="'.$tab_id_2.'"][/vc_tab]
	',
	'js_view' => 'VcTabsView'
) );


vc_map( array(
	'name' => __('Tab', 'Twoot'),
	'base' => 'vc_tab',
	'allowed_container_element' => 'vc_row',
	'is_container' => true,
	'content_element' => false,
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __('Title', 'Twoot'),
			'param_name' => 'title',
			'description' => __('Tab title.', 'Twoot')
		),
		array(
			'type' => 'tab_id',
			'heading' => __('Tab ID', 'Twoot'),
			'param_name' => 'tab_id'
		)
	),
	'js_view' => 'VcTabView'
) );


// Twitter Carousel 
vc_map( array(
	'name' => __('Twitter Carousel', 'Twoot'),
	'base' => 'twitter_carousel',
	'icon' => '',
	'category' => __('Content', 'Twoot'),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __('Counts', 'Twoot'),
			'param_name' => 'counts',
			'value' => '5',
			'description' => __('The number of posts to display on each page.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Cache', 'Twoot'),
			'param_name' => 'cache',
			'value' => '1',
			'description' => __('The cache time (in hour).', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Auto', 'Twoot'),
			'param_name' => 'auto',
			'value' => array(
				__('True', 'Twoot') => 'true',
				__('False', 'Twoot') => 'false'
			),
			'description' => __('(Optional) Auto play the slider (true/false).', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Speed', 'Twoot'),
			'param_name' => 'speed',
			'value' => '800',
			'description' => __('(Optional) Slide transition duration (in ms).', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Pause', 'Twoot'),
			'param_name' => 'pause',
			'value' => '5000',
			'description' => __('(Optional) The amount of time (in ms) between each auto transition.', 'Twoot')
		),
		array(
			'type' => 'dropdown',
			'heading' => __('Mode', 'Twoot'),
			'param_name' => 'mode',
			'value' => array(
				__('Fade', 'Twoot') => 'fade',
				__('Horizontal', 'Twoot') => 'horizontal',
				__('Vertical', 'Twoot') => 'vertical'
			),
			'description' => __('Type of transition between slides.', 'Twoot')
		)
	)
) );


// Video
vc_map( array(
	'name' => __('Video', 'Twoot'),
	'base' => 'video',
	'icon' => '',
	'category' => __('Media', 'Twoot'),
	'params' => array(
		array(
			'type' => 'dropdown',
			'heading' => __('Type', 'Twoot'),
			'param_name' => 'type',
			'value' => array(
				__('Youtube', 'Twoot') => 'youtube',
				__('Vimeo', 'Twoot') => 'vimeo'
			),
			'description' => __('Type of transition between slides.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Url', 'Twoot'),
			'param_name' => 'url',
			'description' => __('The url for the video. ex: "http://vimeo.com/57148705"', 'Twoot')
		),
		array(
			'type' => 'textarea',
			'class' => 'text',
			'heading' => __('Embed', 'Twoot'),
			'param_name' => 'embed',
			'description' => __('If you want to add some other embed code, you can use this option.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Width', 'Twoot'),
			'param_name' => 'width',
			'description' => __('(Optional) The width for the video.', 'Twoot')
		),
		array(
			'type' => 'textfield',
			'heading' => __('Height', 'Twoot'),
			'param_name' => 'height',
			'description' => __('(Optional) The height for the video.', 'Twoot')
		)
	)
) );



/* Support for 3rd Party plugins
---------------------------------------------------------- */
include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
if (is_plugin_active('LayerSlider/layerslider.php')) {
	global $wpdb;
	$ls = $wpdb->get_results( 'SELECT id, name, date_c FROM '.$wpdb->prefix.'layerslider WHERE flag_hidden = "0" AND flag_deleted = "0" ORDER BY date_c ASC LIMIT 100');
	$layer_sliders = array();
	if ($ls) {
		foreach ( $ls as $slider ) {
			$layer_sliders[$slider->name] = $slider->id;
		}
	} else {
		$layer_sliders['No sliders found'] = 0;
	}
	vc_map( array(
		'base' => 'layerslider_vc',
		'name' => __('Layer Slider', 'Twoot'),
		'icon' => '',
		'category' => __('Content', 'Twoot'),
		'params' => array(
			array(
				'type' => 'dropdown',
				'heading' => __('LayerSlider ID', 'Twoot'),
				'param_name' => 'id',
				'admin_label' => true,
				'value' => $layer_sliders,
				'description' => __('Select your LayerSlider.', 'Twoot')
			),
			array(
				'type' => 'textfield',
				'heading' => __('Extra class name', 'Twoot'),
				'param_name' => 'el_class',
				'description' => __('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'Twoot')
			)
		)
	) );
} // if layer slider plugin active