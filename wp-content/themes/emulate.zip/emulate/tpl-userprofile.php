<?php
/**
 * Template Name: User Profile
 *
 * Allow users to update their profiles from Frontend.
 *
 */


if ( !is_user_logged_in() )
{
	$url=get_bloginfo('url').'/login/?redirect='.get_permalink();
    wp_redirect($url);
	exit;
}
 
global $current_user, $wp_roles;
get_currentuserinfo();

 
require_once( ABSPATH . WPINC . '/registration.php' );
$error = array();    
/* If profile was saved, update profile. */
if ( 'POST' == $_SERVER['REQUEST_METHOD'] && !empty( $_POST['action'] ) && $_POST['action'] == 'update-user' ) {

    /* Update user password. */
    if ( !empty($_POST['pass1'] ) && !empty( $_POST['pass2'] ) ) {
        if ( $_POST['pass1'] == $_POST['pass2'] )
            wp_update_user( array( 'ID' => $current_user->ID, 'user_pass' => esc_attr( $_POST['pass1'] ) ) );
        else
            $error[] = __('** The passwords you entered do not match.  Your password was not updated.', 'profile');
    }

    /* Update user information. */
 
    if ( !empty( $_POST['email'] ) ){
        if (!is_email(esc_attr( $_POST['email'] )))
            $error[] = __('** The Email you entered is not valid.  please try again.', 'profile');
        elseif(email_exists(esc_attr( $_POST['email'] )) != $current_user->id )
            $error[] = __('** This email is already used by another user.  try a different one.', 'profile');
        else{
            wp_update_user( array ('ID' => $current_user->ID, 'user_email' => esc_attr( $_POST['email'] )));
        }
    }

    if ( !empty( $_POST['first-name'] ) )
        update_user_meta( $current_user->ID, 'first_name', esc_attr( $_POST['first-name'] ) );
    if ( !empty( $_POST['last-name'] ) )
        update_user_meta($current_user->ID, 'last_name', esc_attr( $_POST['last-name'] ) );
   

    /* Redirect so the page will show updated info.*/
  /*I am not Author of this Code- i dont know why but it worked for me after changing below line to if ( count($error) == 0 ){ */
    if ( count($error) == 0 ) {
        //action hook for plugins and extra fields saving
        do_action('edit_user_profile_update', $current_user->ID);
        wp_redirect( add_query_arg( 'profile', 'updated', get_permalink())   );
        exit;
    }
}

 

$layout = twoot_get_frontend_func('meta', 'layout')==false? 'right':twoot_get_frontend_func('meta', 'layout');
$widget = twoot_get_frontend_func('meta', 'sidebar')==false? 'page':twoot_get_frontend_func('meta', 'sidebar');
?>
<?php get_header(); ?>

<?php
	if( (twoot_get_frontend_func('meta', 'slideshow')==false) && !is_front_page() ) {
		echo twoot_generator('page_title', 'page'); 
	}
?>

<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<div class="site-content container pt pb clearfix">

<?php if($layout=='left') { echo twoot_generator('sidebar', $widget, $layout); } ?>

<article id="primary-wrapper" <?php twoot_layout_class();?>>
	<div class="inner">

	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
    <div id="post-<?php the_ID(); ?>">
        <div class="entry-content entry">
            <?php the_content(); ?>
          <div id="account-settings">  
		  
 
                <?php if ( count($error) > 0 ) echo '<p class="error">' . implode("<br />", $error) . '</p>'; ?>
                
                <?php 
				   
				   if($_REQUEST['profile']=='updated')
				   {
					 echo '<p class="updated">Profile updated.</p>';   
				   }
				
				?>
                
                <form method="post" id="adduser" action="<?php the_permalink(); ?>">
                    <div class="form_field">
                        <div class="frml"><label for="first-name"><?php _e('First Name', 'profile'); ?></label></div>
                       <div class="frmr"> <input class="text-input" name="first-name" type="text" id="first-name" value="<?php the_author_meta( 'first_name', $current_user->ID ); ?>" /></div>
                       <div class="clear"></div>
                    </div> 
                    <div class="form_field">
                       <div class="frml"> <label for="last-name"><?php _e('Last Name', 'profile'); ?></label></div>
                        <div class="frmr"><input class="text-input" name="last-name" type="text" id="last-name" value="<?php the_author_meta( 'last_name', $current_user->ID ); ?>" /></div>
                        <div class="clear"></div>
                    </div> 
                    
                    <div class="form_field">
                        <div class="frml"><label for="email"><?php _e('E-mail *', 'profile'); ?></label></div>
                        <div class="frmr"><input class="text-input" name="email" type="text" id="email" value="<?php the_author_meta( 'user_email', $current_user->ID ); ?>" /></div>
                        <div class="clear"></div>
                    </div>
                    
                    <div class="form_field">
                        <div class="frml"><label for="pass1"><?php _e('New Password *', 'profile'); ?> </label></div>
                        <div class="frmr"><input class="text-input" name="pass1" type="password" id="pass1" /><br />

                        <span class="fnotes">If you would like to change the password type a new one. Otherwise leave this blank.</span>
                        </div>
                        <div class="clear"></div>
                    </div><!-- .form-password -->
                    <div class="form_field">
                        <div class="frml"><label for="pass2"><?php _e('Repeat New Password *', 'profile'); ?></label></div>
                        <div class="frmr"><input class="text-input" name="pass2" type="password" id="pass2" /><br />
<span class="fnotes">Type your new password again.</span>  </div>
                        
                     
                        <div class="clear"></div>
                    </div><!-- .form-password -->
                    

                    <?php 
                        //action hook for plugin and extra fields
                        do_action('edit_user_profile',$current_user); 
                    ?>
                    <p class="form-submit">
                        <?php echo $referer; ?>
                        <input name="updateuser" type="submit" id="updateuser" class="submit button" value="<?php _e('Update Profile', 'profile'); ?>" />
                        <?php wp_nonce_field( 'update-user' ) ?>
                        <input name="action" type="hidden" id="action" value="update-user" />
                    </p><!-- .form-submit -->
                </form><!-- #adduser -->
          </div>
        </div><!-- .entry-content -->
    </div><!-- .hentry .post -->
    <?php endwhile; ?>
<?php else: ?>
    <p class="no-data">
        <?php _e('Sorry, no page matched your criteria.', 'profile'); ?>
    </p><!-- .no-data -->
<?php endif; ?>

	</div>
</article>
<!--end #primary-->

<?php if($layout=='right') { echo twoot_generator('sidebar', $widget, $layout); } ?>

</div>
</div>
<!--end #content-->

<?php get_footer(); ?>