<?php
/**
 * @package WordPress
 * @subpackage ThemeWoot
 * @author ThemeWoot Team 
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */
$format=get_post_format() === false? 'standard':get_post_format();
?>
<?php echo twoot_generator( 'load_template', 'format-' . $format ); ?>

<div class="clearfix">
	<section class="entry-meta">
		<span class="date-link">
			<?php echo get_the_time( get_option('date_format') ); ?>
		</span>
		<?php if(comments_open()) : ?>
		<span class="comments-link">
			<?php comments_popup_link( __( 'Leave a comment', 'Twoot' ), __( '1 Comment', 'Twoot' ), __( '% Comments', 'Twoot' ) ); ?>
		</span>
		<?php endif; ?>
	</section>

	<article class="entry-content clearfix">
		<?php if($categories_list=get_the_category_list( __( ', ', 'Twoot' ) )) : ?>
		<div class="cats-link">
			<?php printf( __( 'Posted in: %1$s', 'Twoot' ), $categories_list ); ?>
		</div>
		<?php endif; ?>
		<h3 class="entry-title item-title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark"><?php the_title(); ?></a></h3>
		<div class="entry-text"><?php echo twoot_generator('post_excerpt', 360, true, '...', __('Continue reading &raquo;', 'Twoot')); ?></div>
	</article>
</div>