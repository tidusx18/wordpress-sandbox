<?php
/**
 * Template Name: Login
 *
 */
 
 
 if ( is_user_logged_in() )
{
	 
	$redirect = esc_url(get_bloginfo('url').'/reporting-dashboard/');
    wp_redirect($redirect);
	exit;
}

 $error = array();
 if ( 'POST' == $_SERVER['REQUEST_METHOD'] && !empty( $_POST['action'] ) && $_POST['action'] == 'login' ) {
	 
	 if ( empty( $_POST['username'] ) )
				 $error[] ='Username is required.';
			if ( empty( $_POST['password'] ) )
				 $error[] ='Password is required';

			if ( is_email( $_POST['username'] ) ) {
				$user = get_user_by( 'email', $_POST['username'] );

				if ( isset( $user->user_login ) )
					$creds['user_login'] 	= $user->user_login;
				else
					$error[]='A user could not be found with this email address.';
					 
			} else {
				$creds['user_login'] 	= $_POST['username'];
			}
			
			if ( count($error) == 0 ) {

				$creds['user_password'] = $_POST['password'];
				$creds['remember']      = true;
				$secure_cookie          = is_ssl() ? true : false;
				$user                   = wp_signon( $creds, $secure_cookie );
				
				
	
				if ( is_wp_error( $user ) ) {
					 
					$error[]=$user->get_error_message();
 
				} else {
	
					if ( ! empty( $_REQUEST['redirect'] ) ) {
						$redirect =urldecode($_REQUEST['redirect']);
					}  else {
						$redirect = esc_url(get_bloginfo('url').'/reporting-dashboard/');
					}
	
					wp_redirect($redirect);
					exit;
				}
			
			}
 }

$layout = twoot_get_frontend_func('meta', 'layout')==false? 'right':twoot_get_frontend_func('meta', 'layout');
$widget = twoot_get_frontend_func('meta', 'sidebar')==false? 'page':twoot_get_frontend_func('meta', 'sidebar');
?>
<?php get_header(); ?>

<?php
	if( (twoot_get_frontend_func('meta', 'slideshow')==false) && !is_front_page() ) {
		echo twoot_generator('page_title', 'page'); 
	}
?>

<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<div class="site-content container pt pb clearfix">

<?php if($layout=='left') { echo twoot_generator('sidebar', $widget, $layout); } ?>

<article id="primary-wrapper" <?php twoot_layout_class();?>>
	<div class="inner">

	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
    <div id="post-<?php the_ID(); ?>">
        <div class="entry-content entry">
            <?php the_content(); ?>
          <div id="account-settings">  
             
             <?php 
			   
			   if($_REQUEST['action']=='reset_success')
			   {
				 echo '<div id="result"><span class="success">Your password has been reset. you can now login with your new password below.</span></div>' ;  
				   
			   }
			 
			 ?>
           
            <?php if ( count($error) > 0 ) echo '<p class="error">' . implode("<br />", $error) . '</p>'; ?>
            <form method="post" class="login">
			 <div class="form_field">
				<div class="frml"><label for="username"><?php _e( 'Username or email', '' ); ?> <span class="required">*</span></label></div>
				<div class="frmr"><input type="text" class="input-text" name="username" id="username" /></div>
                <div class="clear"></div>
			</div>
			
            <div class="form_field">
				<div class="frml"><label for="password"><?php _e( 'Password', '' ); ?> <span class="required">*</span></label></div>
				<div class="frmr"><input class="input-text" type="password" name="password" id="password" /></div>
                <div class="clear"></div>
			</div>

			<p class="form-row">
				 
                <?php //wp_nonce_field( 'login' ) ?>
                 <input name="action" type="hidden" id="action" value="login" />
                 
               
				<input type="submit" class="button" name="login" value="<?php _e( 'Login', '' ); ?>" />
                
                <a style="font-size: 13px;font-weight: bold;margin-left: 10px;" href="<?php echo get_option('siteurl')."/forget-password/"; ?>">Forget Password?</a>
				 
			</p>
            
            
		</form>
        
          
          </div>
        </div><!-- .entry-content -->
    </div><!-- .hentry .post -->
    <?php endwhile; ?>
<?php else: ?>
    <p class="no-data">
        <?php _e('Sorry, no page matched your criteria.', 'profile'); ?>
    </p><!-- .no-data -->
<?php endif; ?>

	</div>
</article>
<!--end #primary-->

<?php if($layout=='right') { echo twoot_generator('sidebar', $widget, $layout); } ?>

</div>
</div>
<!--end #content-->

<?php get_footer(); ?>