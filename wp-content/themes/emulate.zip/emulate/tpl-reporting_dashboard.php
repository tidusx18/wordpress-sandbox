<?php

/**
  * Template Name: Reporting Dashboard
 */
 

if ( !is_user_logged_in() )
{
	$url=get_bloginfo('url').'/login/?redirect='.get_permalink();
    wp_redirect($url);
	exit;
}

$layout = twoot_get_frontend_func('meta', 'layout')==false? 'right':twoot_get_frontend_func('meta', 'layout');

$widget = twoot_get_frontend_func('meta', 'sidebar')==false? 'page':twoot_get_frontend_func('meta', 'sidebar');

function custom_scripts()
{
?>
<script type="text/javascript" src="<?php bloginfo('template_url') ?>/js/paging.js"></script>
<script type="text/javascript">
 
</script>
<?php 	
	
}

add_action('wp_head','custom_scripts');

?>
<?php get_header(); ?>
<?php

	if( (twoot_get_frontend_func('meta', 'slideshow')==false) && !is_front_page() ) {

		echo twoot_generator('page_title', 'page'); 

	}

?>

<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
 
  

  <div class="site-content container pt pb clearfix" style="position:relative;">
  
    <?php if($layout=='left') { echo twoot_generator('sidebar', $widget, $layout); } ?>
    <article id="primary-wrapper" <?php twoot_layout_class();?>>
      <div class="inner">
      <div id="acc_settings"><a href="<?php bloginfo('url') ?>/account-settings/">Account Settings</a> | <a href="<?php echo wp_logout_url(get_permalink()); ?>" title="Logout">Logout</a></div>
        <div id="rdesh">
          <div id="rdesh_head">
            <div id="rdesh_l"> <span class="rtag">FILTER BY:</span>
              <label>Category:</label>
              <?php wp_dropdown_categories('show_option_all=All&taxonomy=sector&hide_empty=0&id=dp_sector&name=sector'); ?>
              <label>Author:</label>
              <?php wp_dropdown_categories('show_option_all=All&taxonomy=author&hide_empty=0&id=dp_author&name=author'); ?>
            </div>
            <div id="rdesh_r"><span class="rtag">SEARCH:</span>
              <input type="text" class="keyword" placeholder="Enter Keyword"  value="" />
              <input type="submit" value="GO" class="go_btn" />
            </div>
            <div class="clear"></div>
          </div>
          <div id="rdesh_main">
            <div id="rheader">
              <div class="col col1">
                <div class="colin">REPORT NAME</div>
              </div>
              <div class="col col2">
                <div class="colin">SECTORS</div>
              </div>
              <div class="col col3">
                <div class="colin">AUTHOR</div>
              </div>
              <div class="col col4">
                <div class="colin">DATE</div>
              </div>
              <div class="col col5">
                <div class="colin">REPORT</div>
              </div>
              <div class="clear"></div>
            </div>
            <div id="rbody">
 
            </div>
            <div id="rfooter"><div class="pagination-holder">
			<div id="light-pagination" class="pagination"></div>
	</div>
    <div class="clear"></div>
    </div>
            
            
    
          </div>
        </div>
      </div>
    </article>
    
    <!--end #primary-->
    
<script type="text/javascript">

 
 

   var ajaxurl='<?php echo admin_url( 'admin-ajax.php' ); ?>';
   
   function setup_dashboard_record(page_flag)
   {
	  jQuery('#rbody').empty().append('<div id="loader"></div>');
	  
	  var cpage;
	  if(page_flag)
	  {
		  
		 cpage=page_flag;
	  }
	  else
	  {
		 cpage=1;  
	  }
	  
	  
	 var data = {
		action: 'dashboard_report',
		sector: jQuery('#dp_sector').val(),
		author: jQuery('#dp_author').val(),
		s: jQuery('.keyword').val(),
		page:cpage
		 
	};
    var html='',curr_page,num_pages,i=1,nav_html,current;
	  
	jQuery.post(ajaxurl, data, function(response) {
		  var data = eval( response );
		  
		 
		  
		  if(data)
		  {
			  jQuery.each(data[0].data, function(index, element) {
				html='<div class="rrow"><div class="col col1"><div class="colin">'+element.t+'</div></div><div class="col col2"><div class="colin">'+element.s+'</div></div><div class="col col3"><div class="colin">'+element.a+'</div></div><div class="col col4"><div class="colin">'+element.d+'</div></div><div class="col col5"><div class="colin"><a class="pdf" target="_blank" href="<?php bloginfo('url') ?>/?download=pdf&id='+element.id+'">Download</a></div></div><div class="clear"></div></div>';
				
			 jQuery('#rbody').append(html);
				
				
			});
			
			
			
			
			
			curr_page=data[0].curr_page;
			num_pages=data[0].num_pages;
			
		   if(num_pages >1)
		   {
 
			  
			   jQuery('#light-pagination').pagination({
					items: num_pages*20,
					itemsOnPage: 20,
					currentPage:curr_page,
					cssStyle: 'light-theme',
					onPageClick:update_page_item
				});
			   
			   
		   }
		   else
		   {
 
				jQuery('#light-pagination').pagination('updateItems', 0);
		   }
		   
		  
			
			 
			 
		  }
		  else
		  {
			  
			  jQuery('#rbody').html('<div id="error_bx">Sorry, we cannot find any reports under that search term.<br />Please try again or view all reports.</div>');
			  
			 jQuery('#light-pagination').pagination('updateItems', 0);
			  
		  }
		  
		  
		   jQuery('#loader').remove();
		
	});   
	   
   }
   
  
  jQuery('#dp_sector,#dp_author').change(
     function()
	 {
		setup_dashboard_record(0); 
		 
	 });
	 
	 jQuery('.go_btn').click(
     function()
	 {
		setup_dashboard_record(0); 
		 
	 });
	 
	 setup_dashboard_record(0); 
     
	 
	  jQuery('#rfooter').on( "click", "span.page", function() {
   
        jQuery('.current.page').removeClass('current');
		jQuery(this).addClass('current'); 
		
		setup_dashboard_record(1);

	 });
	 
	 jQuery('#rfooter').on( "click", "span.prev", function() {
   
        var current=jQuery('.current.page');
		
		if(current.text()>1)
		{
			current.prev().addClass('current');
			current.removeClass('current');
			setup_dashboard_record(1);
		}
		

	 });
	 
	 jQuery('#rfooter').on( "click", "span.next", function() {
   
        var current=jQuery('.current.page');
		
		if(current.text()<jQuery('span.page').length)
		{
			current.next().addClass('current');
			current.removeClass('current');
			setup_dashboard_record(1);
		}
		

	 });
	 
	 
	 function update_page_item(pageNumber,evt)
	 {
		 
		setup_dashboard_record(pageNumber);
	 }
     
   

</script> 
    
    
    <?php if($layout=='right') { echo twoot_generator('sidebar', $widget, $layout); } ?>
  </div>
</div>

<!--end #content-->

<?php get_footer(); ?>
