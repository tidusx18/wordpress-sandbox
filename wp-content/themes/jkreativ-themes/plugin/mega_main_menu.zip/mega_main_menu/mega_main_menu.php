<?php
/**
 * @package Mega Main Menu
 * @version 1.2.0
 * Plugin Name: Mega Main Menu
 * Plugin URI: http://menu.megamain.com
 * Description: Multifunctional and responsive menu. Features: icons, dropdowns, sticky menu, custom styles, images, google fonts. All in one...
 * Version: 1.2.0
 * Author: MegaMain.com
 * Author URI: http://megamain.com
 */
	include_once( 'plugin_framework/primary_class.php' );
?>